# Energiedetektive – Konzept & Roadmap

**Stand:** Mockup v1a (eingefroren) · Übergabe an Folgeprojekt
**Zweck:** Erkenntnisse aus dem Prototyp sichern, Designregeln festschreiben, Schritt-für-Schritt-Plan.

Legende: **`!!`** = vormerken / Backlog · **`:)`** = augenzwinkernd, Satire-Ton im Unterricht

---

## 0. Wo wir stehen

| | Bewertung |
|---|---|
| Als **Mockup / 1. Draft** | überdurchschnittlich – Struktur steht, leicht zu handhaben |
| Als **Produkt** | früh – begleitet Lektionen rudimentär, bis zur vermarktbaren Lösung weiter Weg |
| Fortschritt | grob **¼ bis ⅓** des Weges |

**Stärke:** Redaktion/Didaktik und eigenständige Bildsprache (deutlich über PPTX- und PDF-Arbeitsblatt-Niveau).
**Lücke:** der interaktive Kern – *messen, vergleichen, erklären* ist versprochen, aber noch nicht eingelöst.

---

## 1. Designsystem – die Regeln

### 1.1 Grundprinzip: Panel fix, Bühne variabel

> Panels über **alle Modi einheitlich sehr dunkel**. Nur der Gesamt-Hintergrund wechselt Farbe und Stil.

Folge: Panel-Gestaltung wird **einmal** definiert und gilt überall. Der Modus ist nur noch die „Bühne". Weniger Code, weniger Pflege, garantiert einheitliche Optik.

### 1.2 Die drei Modi

| Modus | Charakter | Bühne |
|---|---|---|
| **Tech** | Explorer, Weltraum | sehr dunkel, feines Punktraster – mehr braucht es nicht |
| **Base** | Normal | dunkles Petrol, Richtung bläulich |
| **Play** | Verspielt | mehr Blau, Lime/Orange als Komplementär |

Kein reines Schwarz, kein reines Weiß. Petrol von dunkel nach hell. Grün = Nachhaltigkeit.

### 1.3 Minimal-Set

- **max. 5 Schriften**, **5 Grundfarben** – damit soll gefühlt alles abgedeckt sein
- **Flow-Farben** (Energie/Flow/Bewegung/Rhythmus) = eigenes Thema, getrennt behandeln `!!`
- **Kein Fett.** Überschriften im angenehmen Grün tragen sich selbst
- Stations-Titel („Energie entdecken") **ohne Großbuchstaben**, im Grünton der Überschriften, evtl. etwas heller `!!`
- Immer **Platz- und Datenoptimierung** – erklärtes Ziel

### 1.4 Proportionen

- 5 Panels horizontal: angenehme **7 breit : 8 hoch**
- sonst **goldener Schnitt 1 : 1,618**  `!!`
- *Offen:* 7:8 steht in leichter Spannung zu „keine Platzverschwendung" – aktuell wachsen die Panels inhaltsbasiert. Entscheidung im Folgeprojekt.

### 1.5 Interaktionsmuster

- **Dark scheme, Apple-Style, deadly simple**
- Keine nervöse Gestaltung. Einfaches Auf/Zu
- **Akkordeon, Hamburger** – lange vertikale Listen vermeiden
- Immer **Oberpunkte → Verzweigung → Parent/Child**, Kaskaden horizontal, dann vertikal
- **Slider: Dots-Optik oben** statt Leisten `!!`
- Idealbild: für den Explorer ein **Dashboard / Cockpit – sonst nichts** `!!`

### 1.6 Lesbarkeit & Medien

- Beamer: 9–12 px sind grenzwertig → Mindestgrößen festlegen `!!`
- Nur dunkle Modi – heller Klassenraum ist oft das erste Problem → **Light-Variante** prüfen `!!`
- GIFs/Animationen insgesamt noch offen; Base64 → **WebP/Video** (Bruchteil der Größe) `!!`

---

## 2. Didaktik – der methodische Kern

Bereits tragfähig: ein Gedanke pro Screen · Merksatz · Mythen-Check · „erst vermuten, dann begründen, dann prüfen" · Beobachtung von Bewertung trennen.

### 2.1 Vertiefung „Energie ist überall"

Vom Sichtbaren zum Unsichtbaren führen:

- Ich sehe eine **Steckdose** – und? Stecker rein, Licht geht an
- Was sehe ich **nicht**? Da fließt etwas von A nach B … Elektronen
- **Fachbegriff** → Herkunft (griechisch), analog CO₂ → Begriffe verankern
- Im Raum fließt mehr, ohne dass wir es merken: es **gluckert** – Heizung, Warmwasser
- Woher kommt das? Woher kommt der Strom?

### 2.2 Gruppen-Loop (Leitmethode der ganzen Woche)

1. **3–4 Gruppen**, 5–10 min zusammensetzen
2. Diskutieren: *Was seht ihr? Was könnte mit Energie zu tun haben?*
   → Heizkörper ist warm, hat einen Drehknopf, steht auf 5 …
   → *Ist das eine Turboheizung* `:)` *oder geht sie um 5 Uhr aus? Was denkt ihr?*
3. **5 Stichpunkte pro Gruppe**, ein Schüler trägt vor
4. Ergebnisse **in die App eintragen** – nächste Gruppe **ergänzt**
5. So entstehen ~20 Funde → **Zusammenfassung: Was haben wir gefunden? Welche Themen?**
6. Überleitung zu Wärme, Strom … `!!`

Die gefundenen Geräte (bzw. eine Auswahl) werden **später gemessen** → Hinweise dazu geben.
**Lehrkraft-Redaktion:** eigene Aufgabe entwerfen können `!!`
**Rundgänge über mehrere Räume**, Ergebnisse **mehrerer Gruppen** `!!`

### 2.3 Vom Verbrauch zu den Kosten

Nach Leistung / Benutzungsdauer / Verbrauch / Arbeit:

- Was kostet der Betrieb eines Geräts – 1 Jahr, 5 Jahre? Was kostet **Handynutzung**?
- Wer kennt seinen **Strompreis**, ungefähr?
- **Recherche im Netz:** Was kostet kWh Strom, m³ Wasser …
- Wer hat schon mal eine **Stromrechnung** gesehen? Die Eltern zahlen *Abschläge* – was ist ein Abschlag?
  *Wie beim Fußball? Oder muss ich einen Ast abschlagen* `:)`
  Und dann: „schon wieder Nachzahlung, Preise gestiegen, ich versteh die Rechnung nicht!"
- **Vertiefung:** Wer bringt nächste Woche eine Rechnung mit? Dann nehmen wir sie gepflegt auseinander `!!`
- Preis eintragen → Kosten pro Zeitraum. Prinzip durchziehen, **Beispielrechnungen**
- Was kostet **Standby**: Beamer, Dashboard, Drucker … `!!`

---

## 3. Datenerfassung – Eingabemasken

Standard-Formulare mit **Reiterstruktur / Hamburger**.

**Kopf:** Titel (z. B. „Elektrische Geräte") · Schule · Datum

**Zeile (ca. 8 Spalten horizontal oder Kaskade mit Details):**

| Feld | Hinweis |
|---|---|
| Raum-Nr. | |
| Lage | EG, 1. OG … |
| Gerät | Name |
| Leistung | kW |
| Benutzungsdauer | h / min / s – pro Tag, pro Stunde … **flexible Eingabe** |
| Verbrauch | **errechnet**, kWh |
| Preis → Kosten | pro Zeitraum |
| Anmerkung | alt, defekt … |

Dazu: **mehrere Räume**, **mehrere Gruppen**, Vergleichsansicht.

> Technisch ohne Konto und ohne Server machbar: ein Gerät (Lehrer-Laptop am Beamer) ist die Sammelstelle, Speicherung lokal, Export/Import als Datei.

---

## 4. Produktbausteine (offen)

- **Werkzeuge** mit echten Funktionen statt gleicher Platzhalterkarten: Glossar, Quiz, Mess-Tools `!!`
- **Inhalte:** Glossar und Mythen sind vorhanden → später einpflegen
- **Redaktionssystem für Lehrkräfte** – Inhalte pflegen ohne Code `!!`
- **Protokoll:** Bilder ergänzen, die 5 wichtigsten Punkte festhalten, am Ende **PDF-Ausgabe** `!!`
- **Navigation gesamtkonzeptionell** durchdenken `!!`
- **„Move it" ist Werkstatt, nicht Lerninhalt** → gehört nicht in die Hauptnavigation `!!`

---

## 5. Roadmap – Schritt für Schritt

| Schritt | Inhalt | Warum hier |
|---|---|---|
| **S0** | Freeze · Zip · GitHub · neues Projekt aufsetzen | sauberer Schnitt |
| **S1** | **Designsystem-Fundament:** Panel/Bühne trennen · 5 Farben + 5 Schriften festziehen · kein Fett · Grün-Überschriften ohne Versalien · Proportionen | wirkt auf **alles** danach – zuerst, sonst dreifache Nacharbeit |
| **S2** | **Navigation & Struktur:** Cockpit/Dashboard als einziger Einstieg · „Move it" raus · Leitidee einordnen · Dots-Slider | Struktur vor Funktion |
| **S3** | **Interaktiver Kern, Stufe 1 – Sammeln:** Gruppen tragen Funde ein, nächste Gruppe ergänzt, Zusammenfassung | **größter Hebel**, kleinste sinnvolle Version |
| **S4** | **Stufe 2 – Messen & Vergleichen:** Geräte-Tabelle, kWh automatisch, mehrere Räume/Gruppen gegenüberstellen | löst das Kernversprechen ein |
| **S5** | **Stufe 3 – Kosten & Transfer:** Preis, Hochrechnung 1/5 Jahre, Standby-Kosten, Stromrechnung | Alltagsbezug, hohe Wirkung |
| **S6** | **Protokoll & PDF-Export** | macht Ergebnisse haltbar |
| **S7** | **Redaktionssystem** + Inhalte füllen (Glossar, Mythen, echte Werkzeuge) | erst wenn Strukturen stehen |
| **quer** | Medien auf WebP · Beamer-Lesbarkeit · Light-Variante · Barrierefreiheit | laufend mitziehen |

**Merksatz für die Reihenfolge:** erst *wie es aussieht* festzurren (S1), dann *wie man sich bewegt* (S2), dann *was es kann* (S3–S6).

---

## 6. Offene Ja/Nein-Punkte aus dem Prototyp

1. Leitidee-Panels: denselben Einrück-Hover wie die 5 Stations-Panels?
2. Flow-Text unter **FREIZEIT** heißt noch „GETEILTE ENERGIE" – umbenennen?
3. **Leitidee** als vierter Einstieg in die Kopfzeile?
4. 7:8-Format für die 5 Panels wieder erzwingen oder inhaltsbasierte Höhe behalten?

---

## 7. Technischer Stand (eingefroren)

- React 19 · Vite 7 · Tailwind 4 · Single-File-Build
- `dist/index.html` ≈ 738 kB (≈ 397 kB gzip) – dominiert von Base64-GIFs
- Quellen: `App.tsx` · `components/` (TraceLab, Leitidee) · `data/` (content, leitidee, traceGifs, originalGifs) · `hooks/useTheme` · `index.css`
- Vorhanden: Tastaturnavigation · `prefers-reduced-motion` · responsiv bis Mobil · Theme-System
