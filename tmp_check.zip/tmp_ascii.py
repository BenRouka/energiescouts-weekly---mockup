from PIL import Image
import numpy as np

p = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\grundriss ohne.png'
im = Image.open(p).convert('L')
W = 200
H = int(im.size[1] / im.size[0] * W * 0.5)
b = np.array(im.resize((W, H)))
print(im.size, W, H)
for y, row in enumerate(b):
    line = ''
    for v in row:
        if v < 100:
            line += '#'
        elif v < 170:
            line += '+'
        elif v < 235:
            line += '.'
        else:
            line += ' '
    print(f'{y:02d} {line}')
