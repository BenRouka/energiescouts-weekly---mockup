from PIL import Image
import numpy as np
import sys, os

d = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\3d'
files = sys.argv[1:] or sorted(f for f in os.listdir(d) if f.endswith('.png'))
for f in files:
    im = Image.open(os.path.join(d, f)).convert('RGB')
    w = 110
    h = max(1, int(im.size[1] / im.size[0] * w * 0.5))
    a = np.array(im.resize((w, h))).astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    print("=" * 20, f, im.size)
    for row in range(h):
        line = ""
        for col in range(w):
            br = (r[row, col] + g[row, col] + b[row, col]) / 3
            if g[row, col] > r[row, col] + 25 and g[row, col] > 40:
                line += "%"
            elif br > 120:
                line += "#"
            elif br > 55:
                line += "+"
            elif br > 25:
                line += "."
            else:
                line += " "
        print(f"{row:02d} {line}")
