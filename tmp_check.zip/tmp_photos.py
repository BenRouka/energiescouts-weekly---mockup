from PIL import Image
import numpy as np
import os

d = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus'
for f in ['rathaus innen.png', 'innen links oben.png', 'innen rechts unten.png', 'innen stirn rechts.png', 'innen von links oben.png']:
    a = np.array(Image.open(os.path.join(d, f)).convert('RGB')).astype(float)
    g = a.mean(2)
    H, W = g.shape
    # vertical edge strength profile (columns) and horizontal
    gx = np.abs(np.diff(g, axis=1)).mean(0)
    gy = np.abs(np.diff(g, axis=0)).mean(1)
    # top 12 column peaks
    order = np.argsort(gx)[::-1]
    peaks = []
    for i in order:
        if all(abs(i - j) > 40 for j in peaks):
            peaks.append(int(i))
        if len(peaks) >= 10:
            break
    print(f, W, H, 'brightness', round(g.mean(), 1))
    print('  vertical-edge x-peaks (0..1):', [round(p / W, 2) for p in sorted(peaks)])
    print('  horiz-edge y-peaks (0..1):', [round(p / H, 2) for p in sorted(np.argsort(gy)[::-1][:400][::40] / np.array([H]))])
    # colour clusters: k means light
    flat = a.reshape(-1, 3)
    # dark pixel fraction (people/foreground often darker)
    print('  dark<60 frac', round((g < 60).mean(), 3), 'skin-ish', round((((flat[:,0] > 90) & (flat[:,0] < 220) & (flat[:,1] > 50) & (flat[:,2] < flat[:,0] * 0.8)).mean()), 3))
