from PIL import Image
import numpy as np

p = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\grundriss ohne.png'
a = np.array(Image.open(p).convert('L'))
m = a < 110
H, W = m.shape


def runs(v, minlen):
    out = []
    s = None
    for i, x in enumerate(v):
        if x and s is None:
            s = i
        elif not x and s is not None:
            if i - s >= minlen:
                out.append((s, i - 1))
            s = None
    if s is not None and len(v) - s >= minlen:
        out.append((s, len(v) - 1))
    return out


print("== HORIZONTAL runs >=120 px ==")
for y in range(H):
    r = runs(m[y], 120)
    if r:
        print(y, r)

print("== VERTICAL runs >=80 px ==")
for x in range(W):
    r = runs(m[:, x], 80)
    if r:
        print(x, r)
