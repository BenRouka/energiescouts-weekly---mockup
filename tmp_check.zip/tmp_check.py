from PIL import Image
import numpy as np
import os

d = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\3d'
for f in sorted(x for x in os.listdir(d) if x.endswith('.png')):
    a = np.array(Image.open(os.path.join(d, f)).convert('RGB')).astype(int)
    # Hintergrund ist sehr dunkel; "Tinte" = deutlich heller oder gruen
    br = a.mean(2)
    ink = (br > 55)
    ys, xs = np.where(ink)
    if len(xs) == 0:
        print(f, 'LEER')
        continue
    print(f"{f:28s} {a.shape[1]}x{a.shape[0]}  Tinte {ink.mean()*100:5.2f}%  "
          f"bbox x {xs.min():4d}-{xs.max():4d}  y {ys.min():4d}-{ys.max():4d}")
