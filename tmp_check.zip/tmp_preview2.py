from PIL import Image
import numpy as np
import sys, os

d = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\3d'
f = sys.argv[1]
cols = int(sys.argv[2]) if len(sys.argv) > 2 else 160
im = Image.open(os.path.join(d, f)).convert('RGB')
a = np.array(im).astype(int)
# max-pool brightness and green-ness to preserve thin lines
rows = int(a.shape[0] / a.shape[1] * cols * 0.5)
ys = np.linspace(0, a.shape[0], rows + 1).astype(int)
xs = np.linspace(0, a.shape[1], cols + 1).astype(int)
br = a.mean(2)
gr = a[..., 1] - (a[..., 0] + a[..., 2]) / 2
out_b = np.zeros((rows, cols))
out_g = np.zeros((rows, cols))
for j in range(rows):
    for i in range(cols):
        blk_b = br[ys[j]:ys[j + 1], xs[i]:xs[i + 1]]
        blk_g = gr[ys[j]:ys[j + 1], xs[i]:xs[i + 1]]
        out_b[j, i] = blk_b.max() if blk_b.size else 0
        out_g[j, i] = blk_g.max() if blk_g.size else 0

print("=" * 20, f, im.size)
for j in range(rows):
    line = ""
    for i in range(cols):
        b, g = out_b[j, i], out_g[j, i]
        if g > 60 and b > 70:
            line += "%"
        elif b > 170:
            line += "#"
        elif b > 90:
            line += "+"
        elif b > 45:
            line += "."
        else:
            line += " "
    print(f"{j:02d} {line}")
