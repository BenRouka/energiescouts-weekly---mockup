

# ---------------------------------------------------------------------------
# 2D-Zeichnungen (Grundriss / Schnitt) - direkt in Pixelkoordinaten
# ---------------------------------------------------------------------------
def new_2d_scene():
    sc = Scene(Cam((0, 0, 1), (0, 0, 0), 60))
    sc.segs = []
    sc.faces = []
    sc.texts2d = []
    return sc


def line2(sc, a, b, st="s"):
    sc.segs.append((np.array([a[0], a[1], 0.0]), np.array([b[0], b[1], 0.0]), st))


def rect2(sc, x0, x1, y0, y1, st="s"):
    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    for i in range(4):
        line2(sc, pts[i], pts[i + 1], st)


def circle2(sc, cx, cy, r, st="thin", n=24):
    pts = [(cx + r * math.cos(a), cy + r * math.sin(a))
           for a in np.linspace(0, 2 * math.pi, n + 1)]
    for i in range(n):
        line2(sc, pts[i], pts[i + 1], st)


def tag2(sc, x, y, n, r=11):
    circle2(sc, x, y, r, "techthin", 20)
    sc.texts2d.append((x, y + 4.5, str(n), 12, GREEN, "middle"))


def person2(sc, fx, fy, hpx, st="thin"):
    head_r = 0.078 * hpx
    cy = fy - hpx + head_r
    circle2(sc, fx, cy, head_r, st, 16)
    neck = fy - 0.84 * hpx
    hip = fy - 0.50 * hpx
    line2(sc, (fx, neck), (fx, hip), st)
    line2(sc, (fx, hip), (fx - 0.075 * hpx, fy), st)
    line2(sc, (fx, hip), (fx + 0.075 * hpx, fy), st)
    line2(sc, (fx, neck), (fx - 0.12 * hpx, fy - 0.45 * hpx), st)
    line2(sc, (fx, neck), (fx + 0.12 * hpx, fy - 0.45 * hpx), st)


def legend2(sc, x, y, items, cols=3, dx=470, dy=31):
    for i, (n, txt) in enumerate(items):
        cx = x + (i % cols) * dx
        cy = y + (i // cols) * dy
        tag2(sc, cx, cy, n, r=10)
        sc.texts2d.append((cx + 18, cy + 4.5, txt, 12, FG2, "start"))


def view_plan():
    sc = new_2d_scene()
    s = 62.0
    ox = 180.0
    oy = 205.0

    def P(x, z):
        return (ox + (x + XL) * s, oy + (z + ZL) * s)

    def line(a, b, st="s"):
        line2(sc, P(*a), P(*b), st)

    def rect(x0, x1, z0, z1, st="s"):
        rect2(sc, *P(x0, z0), *P(x1, z1), st)

    # Umfassungswaende
    rect(-XL - 0.25, XL + 0.25, -ZL - 0.25, ZL + 0.25, "s")
    # Fenster (Aussenkante)
    for sgn in (-1, 1):
        for x in WIN_X:
            line((x - 0.9, sgn * ZL), (x + 0.9, sgn * ZL), "thin")
            line((x - 0.9, sgn * (ZL + 0.25)), (x + 0.9, sgn * (ZL + 0.25)), "thin")
    # Stuetzen
    for x in COLS_X:
        for sgn in (-1, 1):
            rect(x - 0.17, x + 0.17, sgn * ZG - 0.17, sgn * ZG + 0.17, "s")
    # Emporenkante
    for sgn in (-1, 1):
        line((-XL, sgn * ZG), (XL, sgn * ZG), "hidden")
    # Heizkoerper
    for sgn in (-1, 1):
        for x in WIN_X:
            rect(x - 0.8, x + 0.8, sgn * (ZL - 0.20), sgn * (ZL - 0.04), "tech")
            for i in range(1, 5):
                xx = x - 0.8 + i * 0.32
                line((xx, sgn * (ZL - 0.20)), (xx, sgn * (ZL - 0.04)), "techthin")
    # Leuchten
    for x in LAMPS_X:
        cx, cy = P(x, 0)
        r = 0.36 * s
        circle2(sc, cx, cy, r, "tech", 26)
        line2(sc, (cx - r * 1.5, cy), (cx + r * 1.5, cy), "techthin")
        line2(sc, (cx, cy - r * 1.5), (cx, cy + r * 1.5), "techthin")
    # Technik
    rect(-XL, -XL + 0.30, -1.5, 1.5, "tech")            # Leinwand
    rect(-XL + 0.55, -XL + 1.0, -0.20, 0.20, "tech")     # Beamer
    for z in (-2.9, 2.9):
        rect(XL - 0.32, XL - 0.14, z - 0.25, z + 0.25, "tech")
    rect(XL - 0.20, XL, 2.55, 2.95, "tech")              # Bedienpanel
    rect(-XL, -XL + 0.22, -3.4, -2.9, "tech")            # Verteiler
    line((XL, 2.3), (XL, 3.5), "hidden")                 # Tuer
    # Tuerfluegel-Schwenkbogen
    pts = [(XL - 1.2 * math.sin(a), 3.5 - 1.2 * math.cos(a))
           for a in np.linspace(0, math.pi / 2, 16)]
    for i in range(len(pts) - 1):
        line(pts[i], pts[i + 1], "hair")

    # Masse
    line((-XL, ZL + 1.5), (XL, ZL + 1.5), "hair")
    line((-XL, ZL + 1.32), (-XL, ZL + 1.68), "hair")
    line((XL, ZL + 1.32), (XL, ZL + 1.68), "hair")
    tx, ty = P(0, ZL + 1.5)
    sc.texts2d.append((tx, ty - 12, "20,00 m", 14, FG2, "middle"))

    # Nummern
    tag2(sc, *P(WIN_X[4], ZL - 0.12), 1)
    tag2(sc, *P(0, 0), 2, r=0)
    tag2(sc, *P(4.0, -ZG), 3)
    tag2(sc, *P(-2.0, ZG), 4)
    tag2(sc, *P(-XL + 0.2, 0.0), 5)
    tag2(sc, *P(XL - 0.12, 2.75), 6)
    tag2(sc, *P(-XL + 0.12, -3.15), 7)

    # Massstab
    x0, y0 = 70, 760
    m = 5 * s
    line2(sc, (x0, y0), (x0 + m, y0), "s")
    line2(sc, (x0, y0 - 7), (x0, y0 + 7), "s")
    line2(sc, (x0 + m, y0 - 7), (x0 + m, y0 + 7), "s")
    sc.texts2d.append((x0 + m / 2, y0 - 12, "5 m", 13, FG2, "middle"))
    sc.texts2d.append((x0 + m + 40, y0 + 4, "GRUNDRISS · EBENE 0,00", 12, GREEN, "start"))

    legend2(sc, 70, 850, [
        (1, "HEIZKÖRPER (PLATZHALTER)"), (2, "LEUCHTE (PLATZHALTER)"),
        (3, "STÜTZE / EMPORENSTÜTZE"), (4, "EMPORENKANTE"),
        (5, "LEINWAND + BEAMER"), (6, "BEDIENPANEL"),
        (7, "HEIZUNGSVERTEILER"),
    ], cols=3, dx=500, dy=30)
    return sc


def view_section():
    sc = new_2d_scene()
    s = 70.0
    ox = 110.0
    oy = 720.0

    def X(x):
        return ox + x * s

    def Y(y):
        return oy - y * s

    def line(a, b, st="s"):
        line2(sc, (X(a[0]), Y(a[1])), (X(b[0]), Y(b[1])), st)

    def rect(x0, x1, y0, y1, st="s"):
        rect2(sc, X(x0), X(x1), Y(y1), Y(y0), st)

    # Raumkanten
    line((0, 0), (20, 0), "s")
    line((0, 6.4), (20, 6.4), "s")
    line((0, 0), (0, 6.4), "s")
    line((20, 0), (20, 6.4), "s")

    # Fenster im Hintergrund (Wand z = -4)
    for wx in WIN_X:
        x = 10 + wx
        rect(x - 0.9, x + 0.9, 1.0, 3.05, "thin")
        line((x - 0.9, 2.15), (x + 0.9, 2.15), "hair")
        rect(x - 0.78, x + 0.78, 4.05, 5.80, "thin")
        line((x - 0.78, 4.90), (x + 0.78, 4.90), "hair")
        # Heizkoerper
        rect(x - 0.8, x + 0.8, 0.14, 0.76, "tech")
        for i in range(1, 5):
            xx = x - 0.8 + i * 0.32
            line((xx, 0.14), (xx, 0.76), "techthin")

    # Empore + Geländer
    line((0, 3.10), (20, 3.10), "s")
    line((0, 2.92), (20, 2.92), "thin")
    for x in np.arange(1.0, 20, 1.6):
        line((x, 3.10), (x, 2.92), "hair")
    line((0, 4.05), (20, 4.05), "s")
    line((0, 3.58), (20, 3.58), "hair")
    for x in np.arange(0.9, 20, 1.6):
        line((x, 3.10), (x, 4.05), "hair")

    # Stuetzen
    for x in [10 + c for c in COLS_X]:
        rect(x - 0.17, x + 0.17, 0.0, 3.10, "s")
        rect(x - 0.24, x + 0.24, 0.0, 0.12, "thin")
        rect(x - 0.24, x + 0.24, 2.98, 3.10, "thin")

    # Leuchten
    for lx in [10 + c for c in LAMPS_X]:
        line((lx, 6.4), (lx, 5.35), "techthin")
        line((lx - 0.10, 5.35), (lx + 0.10, 5.35), "techthin")
        line((lx - 0.10, 5.35), (lx - 0.34, 5.10), "techthin")
        line((lx + 0.10, 5.35), (lx + 0.34, 5.10), "techthin")
        line((lx - 0.34, 5.10), (lx + 0.34, 5.10), "techthin")
        line((lx - 0.34, 5.10), (lx - 1.25, 0.0), "glow")
        line((lx + 0.34, 5.10), (lx + 1.25, 0.0), "glow")

    # Beamer + Lautsprecher
    rect(0.85, 1.35, 5.90, 6.12, "tech")
    line((1.35, 6.0), (3.8, 4.1), "glow")
    rect(19.62, 19.86, 4.35, 5.05, "tech")

    # Personen
    person2(sc, X(4.4), Y(0), 1.75 * s)
    person2(sc, X(12.5), Y(0), 1.72 * s)
    person2(sc, X(7.9), Y(3.10), 1.70 * s)

    # Masse
    line((-0.9, 0.0), (-0.9, 6.4), "hair")
    line((-1.05, 0.0), (-0.75, 0.0), "hair")
    line((-1.05, 6.4), (-0.75, 6.4), "hair")
    sc.texts2d.append((X(-1.25), Y(3.2), "6,40 m", 13, FG2, "middle"))
    line((20.9, 0.0), (20.9, 3.1), "hair")
    line((20.75, 0.0), (21.05, 0.0), "hair")
    line((20.75, 3.1), (21.05, 3.1), "hair")
    sc.texts2d.append((X(21.2), Y(1.5), "3,10 m", 13, FG2, "middle"))
    line((0, -0.9), (20, -0.9), "hair")
    line((0, -1.05), (0, -0.75), "hair")
    line((20, -1.05), (20, -0.75), "hair")
    sc.texts2d.append((X(10), Y(-0.9) - 10, "20,00 m", 13, FG2, "middle"))

    # Nummern
    tag2(sc, X(11.25), Y(0.45), 1, r=11)
    tag2(sc, X(10.0) + 34, Y(5.2), 2)
    tag2(sc, X(14.0) + 26, Y(1.5), 3)
    tag2(sc, X(3.0), Y(3.85), 4)
    tag2(sc, X(16.25), Y(2.55), 5)
    tag2(sc, X(1.1), Y(5.65), 6)

    # Massstab
    x0, y0 = 70, 830
    line2(sc, (x0, y0), (x0 + 5 * s, y0), "s")
    line2(sc, (x0, y0 - 7), (x0, y0 + 7), "s")
    line2(sc, (x0 + 5 * s, y0 - 7), (x0 + 5 * s, y0 + 7), "s")
    sc.texts2d.append((x0 + 2.5 * s, y0 - 12, "5 m", 13, FG2, "middle"))
    sc.texts2d.append((x0 + 5 * s + 40, y0 + 4, "LÄNGSSCHNITT A–A · BLICK NACH NORDEN",
                       12, GREEN, "start"))

    legend2(sc, 70, 890, [
        (1, "HEIZKÖRPER (PLATZHALTER)"), (2, "LEUCHTE (PLATZHALTER)"),
        (3, "STÜTZE"), (4, "EMPORENGELÄNDER"),
        (5, "FENSTER"), (6, "BEAMER"),
    ], cols=3, dx=500, dy=30)
    return sc


def svg_2d(sc, title, subtitle, note):
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
           f'viewBox="0 0 {W} {H}" font-family="Consolas, \'DejaVu Sans Mono\', monospace">',
           f'<rect width="{W}" height="{H}" fill="{BG}"/>',
           '<defs><radialGradient id="vg" cx="50%" cy="45%" r="72%">'
           '<stop offset="50%" stop-color="#000000" stop-opacity="0"/>'
           '<stop offset="100%" stop-color="#000000" stop-opacity="0.5"/>'
           '</radialGradient></defs>',
           f'<rect width="{W}" height="{H}" fill="url(#vg)"/>']
    for style, cfg in STYLES.items():
        segs = [(a, b) for a, b, st in sc.segs if st == style]
        if not segs:
            continue
        d = " ".join(line_path([a[:2], b[:2]]) for a, b in segs)
        dash = f' stroke-dasharray="{cfg["dash"]}"' if cfg["dash"] else ""
        out.append(f'<path d="{d}" fill="none" stroke="{cfg["color"]}" '
                   f'stroke-width="{cfg["w"]}" stroke-opacity="{cfg["op"]}"{dash} '
                   f'stroke-linecap="round"/>')
    for x, y, s, size, color, anchor in sc.texts2d:
        out.append(f'<text x="{x:.1f}" y="{y:.1f}" fill="{color}" font-size="{size}" '
                   f'text-anchor="{anchor}" letter-spacing="0.8">{s}</text>')
    out.append(f'<rect x="32" y="26" width="620" height="92" fill="{BG}" opacity="0.55"/>')
    out.append(f'<text x="48" y="66" fill="{FG}" font-size="28" letter-spacing="5">{title}</text>')
    out.append(f'<text x="50" y="94" fill="{GREEN}" font-size="13" letter-spacing="2">{subtitle}</text>')
    out.append(f'<text x="40" y="{H - 22}" fill="{FG2}" font-size="12" opacity="0.7">{note}</text>')
    out.append(f'<text x="{W - 40}" y="{H - 22}" fill="{FG2}" font-size="12" opacity="0.55" '
               f'text-anchor="end">Skizze · keine Bauaufnahme</text>')
    out.append(f'<rect x="14" y="14" width="{W - 28}" height="{H - 28}" fill="none" '
               f'stroke="{GREEN_D}" stroke-width="1" opacity="0.45"/>')
    out.append('</svg>')
    return "\n".join(out)


# ---------------------------------------------------------------------------
def save(svg, name):
    path = os.path.join(OUT, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg)
    print("wrote", path)


def main():
    save(svg_doc(view_overview(),
                 "RATHAUSSAAL · ÜBERSICHT",
                 "ZWEI GESCHOSSE · EMPORE · STÜTZEN · TECHNIK-PLATZHALTER",
                 "Axonometrie, zwei Wände aufgeschnitten · weiß = Baukörper, grün gestrichelt = Platzhalter"),
         "01-uebersicht.svg")

    save(svg_doc(view_interior((-8.6, 4.5, 3.0), (7.0, 1.4, -1.6), 62,
                               people=[(-4.5, 1.0), (0.5, -1.4), (4.5, 1.2)]),
                 "RATHAUSSAAL · BLICK VON LINKS OBEN",
                 "INNENANSICHT · EMPORE RECHTS · STÜTZENREIHE · HOHE FENSTER",
                 "Standpunkt Empore links · Personen nur als Platzhalter"),
         "02-innen-links-oben.svg")

    save(svg_doc(view_interior((6.8, 1.6, 3.3), (-6.5, 2.4, -1.9), 60,
                               people=[(-3.5, -0.8), (1.0, 1.5), (4.6, -2.0)]),
                 "RATHAUSSAAL · BLICK VON RECHTS UNTEN",
                 "INNENANSICHT · BLICK ÜBER DIE FLÄCHE ZUR GEGENLIEGENDEN EMPORE",
                 "Standpunkt ebenerdig rechts · Stützen und Empore links"),
         "03-innen-rechts-unten.svg")

    save(svg_2d(view_section(),
                "RATHAUSSAAL · LÄNGSSCHNITT",
                "ZWEI EBENEN · EMPORE · HEIZUNG · LICHT · GERÄTE",
                "Schnitt A–A, Blick auf die Fensterwand · grün gestrichelt = Platzhalter"),
         "04-laengsschnitt.svg")

    save(svg_2d(view_plan(),
                "RATHAUSSAAL · GRUNDRISS",
                "TECHNIK-EBENE · HEIZUNG · LICHT · GERÄTE",
                "20,0 × 8,0 m · grün gestrichelt = Platzhalter · vereinfacht nach Grundriss-Scan"),
         "05-grundriss-technik.svg")


if __name__ == "__main__":
    main()
