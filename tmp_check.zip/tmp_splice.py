import io

src = r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\3d\generator.py'
suf = r'C:\Users\User\Documents\1 open code\new_suffix.py'

with io.open(src, encoding='utf-8') as f:
    lines = f.readlines()

# alles ab der verwaisten Zeile 573 ("    scale = ...") abschneiden
cut = None
for i, ln in enumerate(lines):
    if ln.startswith('    scale = min((W - 2 * margin)'):
        cut = i
        break
assert cut is not None, 'Anker nicht gefunden'
head = ''.join(lines[:cut]).rstrip() + '\n'

with io.open(suf, encoding='utf-8') as f:
    suffix = f.read()

with io.open(src, 'w', encoding='utf-8', newline='\n') as f:
    f.write(head + suffix)
print('ok, Zeilen:', head.count('\n') + suffix.count('\n'))
