import sys, os, numpy as np
sys.path.insert(0, r'C:\Users\User\Documents\1 obsidian\bne\2026-11-01 escouts\basis\img\energy\rathaus\3d')
import generator as g

sc = g.view_overview()
print('segments', len(sc.segs), 'faces', len(sc.faces))
zb = g.build_zbuffer(sc)
runs = g.visible_runs(sc, zb)
for st, rr in runs.items():
    pts = np.concatenate(rr)
    print(st, 'runs', len(rr), 'pts', len(pts),
          'x', round(pts[:, 0].min()), round(pts[:, 0].max()),
          'y', round(pts[:, 1].min()), round(pts[:, 1].max()))
# key corners
for p in [(-10, 0, -4), (10, 0, -4), (-10, 6.4, -4), (10, 6.4, -4),
          (-10, 0, 4), (10, 0, 4), (-10, 6.4, 4), (10, 6.4, 4)]:
    q = sc.cam.view(p)
    print(p, 'z', round(q[2], 1), 'screen', np.round(sc.cam.project(q)))
