import { createContext, createElement, useContext, useEffect, useState, type ReactNode } from "react";

export type ThemeId = "tech" | "standard" | "playful";

export const THEMES: { id: ThemeId; label: string; hint: string; swatch: string[] }[] = [
  { id: "tech", label: "Tech", hint: "kühl, digital", swatch: ["#10171b", "#99cc00", "#235a5b"] },
  { id: "standard", label: "Standard", hint: "warm, petrol", swatch: ["#14282b", "#9fd14a", "#2c7071"] },
  { id: "playful", label: "Playful", hint: "verspielt, dezent", swatch: ["#182a30", "#aadd22", "#2f8a8c"] },
];

const STORAGE_KEY = "ed-theme";
const DEFAULT_THEME: ThemeId = "tech";

const isThemeId = (v: unknown): v is ThemeId => v === "tech" || v === "standard" || v === "playful";

function readStoredTheme(): ThemeId {
  try {
    const s = localStorage.getItem(STORAGE_KEY);
    return isThemeId(s) ? s : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

type ThemeContextValue = { theme: ThemeId; setTheme: (t: ThemeId) => void };

const ThemeContext = createContext<ThemeContextValue | null>(null);

/**
 * Ein einziger Theme-State für die ganze App.
 * Im Freeze rief jede Komponente `useTheme()` mit eigenem useState auf –
 * Desktop- und Mobil-Picker konnten dadurch auseinanderlaufen.
 * Jetzt: Provider hält den Zustand, schreibt `data-theme` + localStorage.
 */
export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<ThemeId>(readStoredTheme);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* Speicher nicht verfügbar (z. B. Privatmodus) – Theme gilt trotzdem für die Sitzung */
    }
  }, [theme]);

  return createElement(ThemeContext.Provider, { value: { theme, setTheme } }, children);
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme() muss innerhalb von <ThemeProvider> verwendet werden.");
  return ctx;
}
