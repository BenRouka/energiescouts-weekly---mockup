# Backlog – gemerkte Punkte (aus `!!` im KONZEPT)

> `!!` = **vormerken**, nicht jetzt diskutieren, nicht jetzt entscheiden, nicht anfassen.
> Diese Liste wird bei den passenden Roadmap-Schritten (S1–S7) wieder hervorgeholt.
> Quelle: `docs/KONZEPT.md` (Stand Freeze ufu-v3).

---

## Designsystem (S1)

- **Flow-Farben** (Energie/Flow/Bewegung/Rhythmus) = eigenes Thema, getrennt behandeln
- **Stations-Titel** („Energie entdecken") ohne Großbuchstaben, im Grünton der Überschriften, evtl. etwas heller
- **goldener Schnitt 1 : 1,618** (zusätzlich zu den 5 Panels)
- **Slider: Dots-Optik oben** statt Leisten
- **Dashboard/Cockpit als Idealbild** für den Explorer – sonst nichts

## Lesbarkeit & Medien (quer)

- **Beamer**: 9–12 px sind grenzwertig → Mindestgrößen festlegen
- **Light-Variante** prüfen (heller Klassenraum)
- **GIFs → WebP/Video** (Base64 ist der Platzfresser)

## Didaktik & Datenerfassung (S3–S6)

- Überleitung zu Wärme, Strom
- **Lehrkraft-Redaktion**: eigene Aufgabe entwerfen können
- **Rundgänge** über mehrere Räume, Ergebnisse mehrerer Gruppen
- **Vertiefung**: Stromrechnung mitbringen und auseinandernehmen
- **Standby-Kosten**: Beamer, Dashboard, Drucker

## Produktbausteine (S7)

- **Werkzeuge** mit echten Funktionen statt Platzhalterkarten (Glossar, Quiz, Mess-Tools)
- **Redaktionssystem für Lehrkräfte** – Inhalte pflegen ohne Code
- **Protokoll**: Bilder ergänzen, 5 wichtigste Punkte, **PDF-Ausgabe**
- **Navigation gesamtkonzeptionell** durchdenken
- **„Move it"** ist Werkstatt, nicht Lerninhalt → nicht in die Hauptnavigation

---

### Abgrenzung: echte Entscheidungen (kein `!!`)

Diese stehen in `KONZEPT.md` Abschnitt 6 und sind **Entscheidungen**, keine Backlog-Notizen:

1. Leitidee-Panels: denselben Einrück-Hover wie die 5 Stations-Panels?
2. Flow-Text unter FREIZEIT heißt noch „GETEILTE ENERGIE" – umbenennen?
3. Leitidee als vierter Einstieg in die Kopfzeile?
4. 7:8-Format für die 5 Panels erzwingen oder inhaltsbasiert lassen?
