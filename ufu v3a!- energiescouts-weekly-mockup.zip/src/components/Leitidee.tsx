import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import { leitidee } from "../data/leitidee";
import { cn } from "../utils/cn";

/* nach dem Aufklappen sanft ins Bild holen – erst wenn die Höhen-Transition durch ist */
function revealLater(el: HTMLElement | null, delay = 480) {
  if (!el) return;
  window.setTimeout(() => el.scrollIntoView({ behavior: "smooth", block: "nearest" }), delay);
}

/**
 * Leitidee – zweistufiges Akkordeon im Stil der 5 Stations-Panels.
 * Ebene 1: 5 Panels horizontal (Kaskade links → rechts), jedes mit „+“.
 * Ebene 2: breiter Reiter-Streifen klappt nach unten auf, Unterpunkte kaskadieren links → rechts.
 * Mobil rückt der Streifen direkt unter die Reihe des aktiven Panels (dense grid + order).
 */
export default function Leitidee({ open }: { open: boolean }) {
  const [active, setActive] = useState<number | null>(null);
  const [last, setLast] = useState(0); // bleibt beim Zuklappen sichtbar, damit der Inhalt nicht „springt“
  const [collapsing, setCollapsing] = useState(false);
  const [notchX, setNotchX] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const stripRef = useRef<HTMLDivElement>(null);
  const btnRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const toggle = (i: number) => {
    if (active === i) {
      setActive(null);
      setCollapsing(true);
      return;
    }
    setActive(i);
    setLast(i);
    setCollapsing(false);
    revealLater(stripRef.current);
  };

  // Ganze Leitidee auf/zu: beim Öffnen ins Bild holen, beim Schließen Details einklappen
  useEffect(() => {
    if (open) revealLater(rootRef.current);
    else {
      setActive(null);
      setCollapsing(false);
    }
  }, [open]);

  // Reiter-Nase mittig unter dem aktiven Panel halten (auch bei Resize)
  useLayoutEffect(() => {
    const measure = () => {
      const b = btnRefs.current[active ?? last];
      if (b) setNotchX(b.offsetLeft + b.offsetWidth / 2);
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [active, last, open]);

  const shown = leitidee[active ?? last];
  const expanded = active !== null;
  const closed = !expanded && !collapsing;

  return (
    <div
      ref={rootRef}
      className="grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(.2,.7,.2,1)] scroll-mt-[76px] scroll-mb-4"
      style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
      aria-hidden={!open}
      inert={!open}
    >
      <div className="overflow-hidden min-h-0">
        <div className="pt-7 pb-3">
          {/* Kopf */}
          <div className={cn("mb-4", open ? "rise-in" : "opacity-0")}>
            <div className="font-tech font-medium text-[11px] tracking-[0.14em] t-muted uppercase mb-1.5">Leitidee</div>
            <h2 className="font-display font-semibold tracking-tight text-[clamp(24px,3vw,38px)] t-lime leading-none">Detektive statt Zuhörer.</h2>
            <p className="text-[14px] t-muted leading-relaxed mt-2 max-w-[640px]">
              Fünf Grundsätze, nach denen jede Station, jeder Screen und jede Mission gebaut ist. <span className="t-text font-semibold">+</span> öffnet die Details.
            </p>
          </div>

          {/* Ebene 1: 5 Panels · dense, damit der Streifen mobil unter die Reihe des aktiven Panels rückt */}
          <div className="relative grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 grid-flow-row-dense gap-2.5">
            {leitidee.map((p, i) => {
              const on = active === i;
              return (
                <button
                  key={p.num}
                  ref={(el) => { btnRefs.current[i] = el; }}
                  onClick={() => toggle(i)}
                  aria-expanded={on}
                  style={{ order: i * 2, animationDelay: `${i * 70}ms` }}
                  className={cn(
                    /* Hover wie in B: Rahmen leuchtet auf, kein Versatz.
                       Offenes Panel bleibt leicht angehoben – als Zustand, nicht als Hover. */
                    "group relative text-left p-3.5 border rounded-[var(--c-radius)] surface-dark overflow-hidden transition duration-200 cursor-pointer flex flex-col",
                    open ? "rise-in" : "opacity-0",
                    on ? "bd-strong" : "bd hover:bd-strong"
                  )}
                >
                  <span className="absolute -right-1 -bottom-3 font-display font-semibold text-[64px] leading-none opacity-[0.07] group-hover:opacity-[0.13] transition pointer-events-none" aria-hidden>{p.num}</span>
                  <span className="text-[26px] leading-none block" style={{ color: p.color }}>{p.icon}</span>
                  <span className="block font-tech font-medium text-[10px] leading-[12px] t-faint tracking-[0.12em] mt-3">LEITIDEE {p.num}</span>
                  <span className="block font-display font-medium text-[16px] t-text mt-1 leading-[1.15]">{p.title}</span>
                  <span className="block text-[12px] t-muted leading-[1.35] mt-1.5 flex-1">{p.teaser}</span>
                  {/* Fußzeile: Hinweis + „+“ (dreht sich zum ×) */}
                  <span className="mt-3 flex items-center justify-between">
                    <span className="font-tech font-medium text-[10px] tracking-[0.12em]" style={{ color: p.color }}>{on ? "WENIGER" : "MEHR"}</span>
                    <span
                      className={cn(
                        "inline-grid place-items-center w-7 h-7 rounded-full border text-[17px] leading-none font-display transition-all duration-300",
                        on ? "rotate-45 border-transparent" : "bd-strong t-text"
                      )}
                      style={on ? { background: p.color, color: "#10231b" } : undefined}
                      aria-hidden
                    >
                      +
                    </span>
                  </span>
                </button>
              );
            })}

            {/* Ebene 2: Reiter-Streifen · mobil direkt nach dem aktiven Panel, ab lg unter der ganzen Reihe */}
            <div
              ref={stripRef}
              className="col-span-full grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(.2,.7,.2,1)] order-[var(--o)] lg:order-last scroll-mt-[76px] scroll-mb-4"
              style={{ "--o": closed ? 9999 : (active ?? last) * 2 + 1, gridTemplateRows: expanded ? "1fr" : "0fr" } as CSSProperties}
              onTransitionEnd={() => { if (!expanded) setCollapsing(false); }}
              aria-hidden={!expanded}
              inert={!expanded}
            >
              <div className="overflow-hidden min-h-0">
                <div key={shown.num} className="view-in relative mt-2.5 border bd-strong rounded-[var(--c-radius)] surface-dark p-4 md:p-5">
                  {/* Reiter-Nase */}
                  <span className="absolute -top-[7px] w-3 h-3 -translate-x-1/2 rotate-45 surface-dark border-l border-t bd-strong" style={{ left: notchX }} aria-hidden />

                  <div className="grid lg:grid-cols-[1fr_1.618fr] gap-4 lg:gap-6 items-start">
                    <div>
                      <div className="font-tech font-medium text-[10px] tracking-[0.12em] t-faint">LEITIDEE {shown.num} · {shown.title.toUpperCase()}</div>
                      <div className="font-display font-semibold text-[clamp(20px,2.4vw,28px)] leading-[1.1] mt-1.5" style={{ color: shown.color }}>{shown.kern}</div>
                    </div>
                    {/* Unterpunkte: Kaskade links → rechts */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                      {shown.punkte.map((s, j) => (
                        <div key={s.label} className="rise-in border bd rounded-xl surface-alt p-3" style={{ animationDelay: `${140 + j * 80}ms` }}>
                          <div className="flex items-center gap-1.5 font-tech font-medium text-[10px] tracking-[0.12em] t-text">
                            <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: shown.color }} aria-hidden />
                            {s.label}
                          </div>
                          <div className="text-[12px] t-muted leading-[1.35] mt-1">{s.text}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
