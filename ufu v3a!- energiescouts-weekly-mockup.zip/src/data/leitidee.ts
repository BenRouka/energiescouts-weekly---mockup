// Leitidee der Projektwoche: fünf Oberpunkte mit je vier kurzen Unterpunkten.
// Farben = Trace-Farben aus „Move it“ (Energie · Flow · Bewegung · Rhythmus).

export type LeitideePunkt = {
  num: string;
  icon: string;
  title: string;
  teaser: string;
  kern: string;
  color: string;
  punkte: { label: string; text: string }[];
};

export const leitidee: LeitideePunkt[] = [
  {
    num: "01",
    icon: "◐",
    title: "Detektiv statt Zuhörer",
    color: "#99cc00",
    teaser: "Schüler:innen ermitteln selbst – vermuten, begründen, prüfen.",
    kern: "Wer selbst misst, glaubt sich selbst.",
    punkte: [
      { label: "VERMUTEN", text: "Jede Mission beginnt mit einer eigenen Annahme." },
      { label: "BEGRÜNDEN", text: "Warum glaubst du das? Erst denken, dann handeln." },
      { label: "PRÜFEN", text: "Messwerte entscheiden – nicht Meinungen." },
      { label: "TRENNEN", text: "Beobachtung ist noch keine Bewertung." },
    ],
  },
  {
    num: "02",
    icon: "▭",
    title: "Kurz statt Wand",
    color: "#4CA4C7",
    teaser: "Ein Screen, ein Gedanke. Lesbar am Beamer, greifbar am iPad.",
    kern: "Weniger Text, mehr Blick.",
    punkte: [
      { label: "EIN GEDANKE", text: "Pro Screen genau eine Idee – nicht mehr." },
      { label: "MERKSATZ", text: "Jeder Screen endet mit einem Satz, der bleibt." },
      { label: "SKIZZE", text: "Bewegte Linien zeigen, was Worte nur verlängern." },
      { label: "RHYTHMUS", text: "Mission · Rätsel · Wissen · Mythos – im Wechsel." },
    ],
  },
  {
    num: "03",
    icon: "✕",
    title: "Mythen knacken",
    color: "#F2911A",
    teaser: "Verbreitete Annahmen werden geprüft statt übernommen.",
    kern: "Irrtümer sind die besten Einstiege.",
    punkte: [
      { label: "THERMOSTAT 5", text: "Kein Turbo – nur eine höhere Zieltemperatur." },
      { label: "STANDBY", text: "Nicht immer viel. Aber: messen statt raten." },
      { label: "KIPPLÜFTEN", text: "Kurz und kräftig schlägt lang und lau." },
      { label: "VERZICHT", text: "Klüger nutzen heißt nicht weniger leben." },
    ],
  },
  {
    num: "04",
    icon: "⌗",
    title: "Messen statt meinen",
    color: "#9E75C8",
    teaser: "Jede Station hat Aufträge mit echten Geräten und echten Daten.",
    kern: "Ein Messwert ohne Kontext ist nur eine Zahl.",
    punkte: [
      { label: "GERÄTE", text: "Thermometer, Luxmeter, Energiekostenmessgerät." },
      { label: "PROTOKOLL", text: "Ort, Zeitpunkt, Wert – immer alle drei." },
      { label: "VERGLEICH", text: "Höchstwert, Tiefstwert – und den Unterschied erklären." },
      { label: "HOCHRECHNEN", text: "Aus Watt und Stunden werden kWh und Euro." },
    ],
  },
  {
    num: "05",
    icon: "↗",
    title: "Schule verändern",
    color: "#99cc00",
    teaser: "Aus Funden werden Maßnahmen – und aus Maßnahmen Routinen.",
    kern: "Gelernt ist erst, was sich ändert.",
    punkte: [
      { label: "DREI EBENEN", text: "Verhalten · Organisation · Technik." },
      { label: "PRIORITÄT", text: "Wirkung × Aufwand × Akzeptanz." },
      { label: "SICHTBAR", text: "Ein Hinweis genau dort, wo gehandelt wird." },
      { label: "DIENST", text: "Energiespar-Routine mit klaren Zuständigkeiten." },
    ],
  },
];
