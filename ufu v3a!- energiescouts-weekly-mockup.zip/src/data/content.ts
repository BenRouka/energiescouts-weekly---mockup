// Inhalte 1:1 aus dem HTML-Mockup „energiescout woche – mockup" übernommen.

export type Station = {
  num: string;
  icon: string;
  title: string;
  teaser: string;
  accent: string;
};

export const stations: Station[] = [
  { num: "01", icon: "⚡", title: "ENERGIE ENTDECKEN", teaser: "Was ist Energie, woher kommt sie – und warum lohnt sich Energiesparen?", accent: "#a6dc45" },
  { num: "02", icon: "◉", title: "WÄRME IM BLICK", teaser: "Temperatur, Heizen und Lüften: Wo bleibt die Wärme – und wo geht sie verloren?", accent: "#ff9d00" },
  { num: "03", icon: "⌁", title: "STROM AUF SPURENSUCHE", teaser: "Geräte, Leistung und Verbrauch: Was läuft wirklich – und wie viel kostet das?", accent: "#2db7e9" },
  { num: "04", icon: "⌕", title: "SCHULE UNTER DER LUPE", teaser: "Wir messen, vergleichen und suchen die echten Energielecks unserer Schule.", accent: "#c987ef" },
  { num: "05", icon: "✦", title: "WIR VERÄNDERN WAS", teaser: "Aus Daten werden Ideen: Maßnahmen entwickeln, testen und andere überzeugen.", accent: "#a6dc45" },
];

export type Tool = { icon: string; label: string; sub: string; kicker: string; title: string; text: string };

export const tools: Tool[] = [
  { icon: "▦", label: "ÜBERSICHT", sub: "Zurück zum Dashboard", kicker: "WERKZEUG", title: "Der zentrale Einstieg", text: "Das Dashboard bündelt die fünf Stationen und alle Zusatzbereiche." },
  { icon: "A–Z", label: "GLOSSAR", sub: "Begriffe schnell nachschlagen", kicker: "WERKZEUG", title: "Begriffe schnell verstehen", text: "Kurze, jugendgerechte Erklärungen von Energie bis kWh." },
  { icon: "×", label: "MYTHEN-CHECK", sub: "Stimmt das wirklich?", kicker: "WERKZEUG", title: "Stimmt das wirklich?", text: "Thermostat auf 5, Standby, Kipplüften & weitere typische Irrtümer." },
  { icon: "✦", label: "WISSEN", sub: "Kompakte Wissenskarten", kicker: "WERKZEUG", title: "Wissen kompakt", text: "Die wichtigsten Zusammenhänge als kurze Karten – zum Wiederholen." },
  { icon: "⌁", label: "MESS-TOOLS", sub: "Messaufträge und Rechner", kicker: "WERKZEUG", title: "Messen & rechnen", text: "Temperatur, Licht, Leistung, Verbrauch und einfache Hochrechnungen." },
  { icon: "?", label: "QUIZ", sub: "Teste, was hängen geblieben ist", kicker: "WERKZEUG", title: "Teste dich", text: "Kurze Fragen nach jeder Station – ohne Prüfungsgefühl." },
  { icon: "◎", label: "PROJEKT", sub: "Ergebnisse und Aktionsideen", kicker: "WERKZEUG", title: "Aus Erkenntnissen wird Handlung", text: "Checklisten, Energiespardienst, Hinweise, Veröffentlichungen und Aktionsideen." },
  { icon: "ⓘ", label: "INFO", sub: "Ablauf, Hinweise und Material", kicker: "WERKZEUG", title: "Ablauf & Material", text: "Hinweise für Gruppenarbeit, Messgeräte und spätere echte Schulmaterialien." },
];

// Screen-Tupel: [Typ, Titel, Text, GIF-Key|null, Visual-Titel, Merksatz/Hinweis]
export type Screen = [string, string, string, string | null, string, string];

export const screens: Record<string, Screen[]> = {
  "1": [
    ["MISSION 01", "ENERGIE IST ÜBERALL", "Schau dich um. Nenne drei Dinge im Raum, die Energie nutzen – und eines, in dem Energie gespeichert sein kann.", "mensch", "MENSCH / BEWEGUNG", "Entdecke Energie zuerst in deiner eigenen Umgebung."],
    ["RÄTSEL", "WO IST DIE ENERGIE HIN?", "Eine Lampe leuchtet eine Stunde. Die Energie ist nicht verschwunden. Was ist passiert?", null, "SKIZZE: ELEKTRISCHE → LICHT + WÄRME", "Die Energie wird übertragen und in andere Energieformen umgewandelt."],
    ["WISSEN", "ENERGIE HAT VERSCHIEDENE FORMEN", "Bewegung, Lage, Wärme, elektrische, chemische und Strahlungsenergie begegnen uns ständig.", "fahrrad", "FAHRRAD / ENERGIEKETTE", "Die Form ändert sich – Energie wird nicht einfach „weg“."],
    ["RÄTSEL", "WOHER KOMMT DIE ENERGIE?", "Ordne zu: Sonne, Wind, Kohle, Erdöl, Wasser, Erdgas. Welche Quellen sind erneuerbar?", null, "SKIZZE: ERNEUERBAR ↔ NICHT ERNEUERBAR", "Erneuerbar bedeutet: Die Quelle erneuert sich auf menschlichen Zeitskalen."],
    ["FAKT", "FOSSIL ODER ERNEUERBAR?", "Fossile Energieträger sind über sehr lange Zeit entstanden. Ihre Nutzung setzt bei Verbrennung Kohlenstoff als CO₂ frei.", null, "SKIZZE: QUELLE → UMWANDLUNG → NUTZUNG", "Energiesparen reduziert den Bedarf – unabhängig davon, wie „grün“ die einzelne Technik ist."],
    ["MYTHOS", "DER TREIBHAUSEFFEKT IST SCHLECHT.", "Nicht der natürliche Treibhauseffekt ist das Problem. Er macht die Erde überhaupt erst bewohnbar. Problematisch ist seine Verstärkung durch zusätzliche Treibhausgase.", null, "SKIZZE: ATMOSPHÄRE / WÄRMESTRAHLUNG", "Klimawandel verstehen heißt Ursache, Wirkung und natürliche Prozesse auseinanderhalten."],
    ["MISSION 02", "KLIMASCHUTZ ODER ANPASSUNG?", "Sortiere Beispiele: Energie sparen, Hitzeschutz, Hochwasserschutz, erneuerbare Energien. Was bekämpft Ursachen, was reagiert auf Folgen?", null, "ZWEI KARTEN: SCHÜTZEN / ANPASSEN", "Klimaschutz begrenzt Ursachen. Anpassung reduziert Risiken durch Folgen."],
    ["ABSCHLUSSMISSION", "ENERGIE-DETEKTIV", "Finde im Klassenzimmer drei Energieumwandlungen. Notiere: Woher kommt die Energie? Was passiert mit ihr?", "schaukel", "BEWEGUNG / UMWANDLUNG", "Morgen wird aus Beobachtung eine echte Untersuchung: Wärme."],
  ],
  "2": [
    ["MISSION 01", "WARM ODER KALT?", "Schätze: Welcher Raum ist wärmer? Fensterseite, Heizkörpernähe, Tür oder Raummitte? Begründe zuerst – dann messen.", null, "MESSPUNKT-PLATZHALTER", "Vermuten ist der Start. Messen entscheidet."],
    ["RÄTSEL", "THERMOSTAT AUF 5 = TURBO?", "Stimmt das? Ein Thermostat auf 5 macht den Raum nicht einfach schneller warm. Es steht für eine höhere Zieltemperatur.", null, "SKIZZE: THERMOSTAT 1–5", "Die Regelung bestimmt vor allem die Zieltemperatur."],
    ["WISSEN", "WÄRME BEWEGT SICH", "Wärme kann durch Leitung, Strömung und Strahlung übertragen werden. Fenster, Außenwände und Lüften spielen dabei eine Rolle.", null, "SKIZZE: RAUM / WÄRME-TRACES", "Ein Raum ist ein System – nicht nur ein Heizkörper."],
    ["MISSION 02", "RICHTIG LÜFTEN", "Vergleiche: Fenster dauerhaft gekippt oder kurz weit geöffnet? Was passiert mit Luft und Wärme?", null, "SKIZZE: KIPPEN ↔ STOẞLÜFTEN", "Für beheizte Räume ist langes Kipplüften häufig ungünstiger als kurzes, intensives Lüften."],
    ["MESSAUFTRAG", "TEMPERATUR-EXPEDITION", "Messt mehrere Räume und Punkte. Markiert Höchstwert, Tiefstwert und auffällige Unterschiede.", null, "[ PLATZHALTER FÜR ECHTE MESSDATEN ]", "Nicht nur messen: Unterschiede erklären."],
    ["ABSCHLUSSMISSION", "DAS WÄRME-PROBLEM", "Wählt eine beobachtete Schwachstelle. Formuliert: Problem → Ursache → mögliche Maßnahme.", null, "[ FOTO AUS DER SCHULE ]", "Station 3 bringt uns vom Raum zur elektrischen Energie."],
  ],
  "3": [
    ["MISSION 01", "WAS LÄUFT HIER?", "Zählt Geräte im Raum. Welche sind gerade aktiv? Welche könnten laufen, obwohl niemand sie braucht?", null, "SKIZZE: GERÄTE / STANDBY", "Verbrauch hängt nicht nur vom Gerät, sondern auch von seiner Nutzung ab."],
    ["RÄTSEL", "WATT ODER KWH?", "80 Watt ist Leistung. Kilowattstunden beschreiben eine Energiemenge. Je länger ein Gerät läuft, desto mehr Energie kann es verbrauchen.", null, "SKIZZE: W × ZEIT → kWh", "Leistung und Verbrauch sind nicht dasselbe."],
    ["MESSAUFTRAG", "ENERGIEFRESSER ODER NICHT?", "Messt ausgewählte Geräte. Vergleicht Leistung im Betrieb und – wenn möglich – im Standby.", null, "[ PLATZHALTER: ENERGIEKOSTENMESSGERÄT ]", "Messwerte machen aus Vermutungen belastbare Hinweise."],
    ["MYTHOS", "STANDBY VERBRAUCHT IMMER VIEL.", "Nicht jedes moderne Gerät verbraucht im Standby viel. Aber: Einige Geräte ziehen weiterhin Strom – deshalb messen statt raten.", null, "SKIZZE: AUS / STANDBY / AN", "Die Größenordnung entscheidet."],
    ["MISSION 02", "RECHNE HOCH", "Was passiert, wenn ein Gerät täglich 6 Stunden läuft? Rechnet aus Leistung × Zeit und vergleicht zwei Geräte.", null, "[ PLATZHALTER: RECHNER ]", "Jetzt wird aus Watt eine verständliche Verbrauchsgröße."],
    ["ABSCHLUSSMISSION", "DER GERÄTE-CHECK", "Wählt ein Gerät aus und formuliert eine konkrete Nutzungsempfehlung.", "freizeit", "ENERGIEFLUSS / AKTEURE", "Station 4 verbindet einzelne Messungen zu einem Bild der ganzen Schule."],
  ],
  "4": [
    ["MISSION 01", "DIE SCHULE ALS ENERGIESYSTEM", "Teams übernehmen Wärme, Strom, Licht und Nutzung. Eure Aufgabe: Hinweise sammeln – noch nichts vorschnell bewerten.", null, "[ SCHULPLAN / FOTO-PLATZHALTER ]", "Gute Detektive unterscheiden Beobachtung und Bewertung."],
    ["MESSAUFTRAG", "ENERGIERUNDGANG", "Messt Temperaturen, Beleuchtung und ausgewählte Stromverbräuche. Dokumentiert Ort, Zeitpunkt und Messwert.", null, "[ PLATZHALTER: MESSFORMULAR ]", "Ein Messwert ohne Kontext ist schwer zu beurteilen."],
    ["RÄTSEL", "WO IST DER HÖCHSTE WERT?", "Vergleicht eure Gruppen. Wo wurde die höchste Temperatur gemessen? Wo die niedrigste? Was könnte die Ursache sein?", null, "[ PLATZHALTER: DATENKARTE ]", "Unterschiede sind Hinweise – noch kein Beweis für Verschwendung."],
    ["WISSEN", "VON DATEN ZU EVIDENZ", "Gute Untersuchung heißt: messen, vergleichen, erklären und Unsicherheiten benennen.", null, "SKIZZE: MESSEN → VERGLEICHEN → ERKLÄREN", "Das ist der wissenschaftliche Kern der Projektwoche."],
    ["MISSION 02", "DIE TOP 3 ENERGIELECKS", "Bewertet eure Funde nach Wirkung und Veränderbarkeit. Was wäre leicht zu ändern? Was braucht Technik oder Organisation?", null, "[ PLATZHALTER: PRIORISIERUNGSMATRIX ]", "Nicht jede gute Idee ist sofort umsetzbar."],
    ["ABSCHLUSSMISSION", "UNSER SCHUL-CHECK", "Erstellt eine kurze Beweiskarte: Problem + Messwert + Ursache + mögliche Lösung.", null, "[ FOTO / GRAFIK / ECHTE SCHULDATEN ]", "Damit habt ihr die Grundlage für echte Veränderung."],
  ],
  "5": [
    ["MISSION 01", "WAS KÖNNEN WIR ÄNDERN?", "Sammelt Maßnahmen auf drei Ebenen: Verhalten, Organisation, Technik.", null, "SKIZZE: MENSCH / REGEL / TECHNIK", "Gute Lösungen schieben Verantwortung nicht nur auf einzelne Personen."],
    ["RÄTSEL", "WELCHE MASSNAHME BRINGT AM MEISTEN?", "Vergleicht drei Ideen. Bewertet Wirkung, Aufwand und Akzeptanz.", null, "[ PLATZHALTER: WIRKUNG × AUFWAND ]", "Die beste Lösung ist nicht immer die spektakulärste."],
    ["MISSION 02", "ENERGIESPAR-DIENST", "Entwickelt eine einfache Routine: Was wird wann kontrolliert? Wer ist zuständig?", null, "[ PLATZHALTER: CHECKLISTE ]", "Dauerhafte Veränderung braucht klare Zuständigkeiten."],
    ["GESTALTEN", "MACHT ES SICHTBAR", "Entwerft einen Hinweis für genau den Ort, an dem eine Handlung stattfinden soll: Lichtschalter, Fenster, Smartboard, Drucker …", null, "[ FOTO-PLATZHALTER + HINWEISSCHILD ]", "Ein guter Hinweis ist kurz, freundlich und konkret."],
    ["MYTHOS", "ENERGIESPAREN = VERZICHT", "Nicht automatisch. Gute Maßnahmen reduzieren unnötigen Verbrauch, ohne sinnvollen Komfort zu zerstören.", null, "SKIZZE: KOMFORT ↔ VERBRAUCH", "Ziel ist eine klügere Nutzung, nicht möglichst wenig Nutzung."],
    ["ABSCHLUSSMISSION", "UNSERE ENERGIE-AKTION", "Veröffentlicht eure Ergebnisse: Homepage, Infoboard, Schülerzeitung, Meme, Poster oder kurzer Pitch.", "freizeit", "FREIZEIT / ENERGIE-AKTION", "Ihr habt nicht nur gelernt – ihr habt eine Veränderung angestoßen."],
  ],
};

// SVG-Skizzen für Screens ohne GIF. Ruhige Linienlogik: wenige klare Striche,
// dezenter Grundriss (opacity), EIN farbiger Flow-Trace mit sanfter Animation
// (class="flow-dash", siehe index.css).
const flow = (a: string, d: string) =>
  `<path class="flow-dash" stroke="${a}" stroke-width="6" d="${d}"/>`;

export const sketchPaths: Record<string, (accent: string) => string> = {
  "1-1": (a) => `<path opacity=".22" d="M70 272H530"/><circle cx="180" cy="112" r="32"/><path d="M180 146v86M180 168l-46 58M180 168l46 58M180 232l-40 50M180 232l40 50"/>${flow(a, "M262 150h188")}`,
  "1-3": (a) => `<path opacity=".22" d="M70 272H530"/><circle cx="150" cy="126" r="28"/><path d="M204 126h64M300 96v58M334 126h64M462 126h58"/>${flow(a, "M120 214h360")}`,
  "1-5": (a) => `<path opacity=".22" d="M70 282H530"/><path d="M112 162a48 48 0 1 1 96 0M160 114v96M112 162h96"/><rect x="332" y="124" width="86" height="86" rx="16"/>${flow(a, "M214 167h118")}`,
  "1-6": (a) => `<path opacity=".22" d="M90 252h420"/><path d="M96 252c88-116 320-116 408 0"/>${flow(a, "M300 250V126")}<path d="M272 154l28-28 28 28"/>`,
  "2-1": (a) => `<path opacity=".22" d="M70 282H530"/><rect x="122" y="94" width="356" height="186" rx="16"/><path d="M192 260V146h66M340 260V146h66"/><circle cx="192" cy="182" r="8" fill="${a}" stroke="none"/>${flow(a, "M152 118h296")}`,
  "2-3": (a) => `<path opacity=".22" d="M70 282H530"/><rect x="122" y="94" width="356" height="186" rx="16"/><path d="M222 172c24-32 52-32 78 0s52 32 78 0"/>${flow(a, "M152 118h296")}`,
  "2-5": (a) => `<path opacity=".22" d="M70 282H530"/><path d="M124 240h124M152 240v-86M124 154h58"/><path d="M332 240h124M430 240v-86M402 154h58"/>${flow(a, "M252 196h80")}`,
  "3-0": (a) => `<path opacity=".22" d="M70 282H530"/><rect x="104" y="98" width="120" height="82" rx="12"/><path d="M162 180v42M128 222h68"/><rect x="392" y="92" width="100" height="140" rx="16"/><circle cx="442" cy="204" r="7" fill="${a}" stroke="none"/>${flow(a, "M228 140h164")}`,
  "3-3": (a) => `<path opacity=".22" d="M70 282H530"/><circle cx="172" cy="168" r="52"/><path d="M172 116v52l38 24"/><path d="M332 144h58M332 168h86M332 192h44"/>${flow(a, "M430 124v96")}`,
  "4-3": (a) => `<path opacity=".22" d="M70 282H530"/><circle cx="152" cy="152" r="32"/><circle cx="300" cy="152" r="32"/><circle cx="448" cy="152" r="32"/><path opacity=".5" d="M184 152h84M332 152h84"/>${flow(a, "M120 232h360")}`,
  "5-0": (a) => `<path opacity=".22" d="M70 282H530"/><circle cx="152" cy="134" r="24"/><path d="M152 158v56M124 192h56"/><rect x="272" y="124" width="66" height="92" rx="12"/><circle cx="470" cy="152" r="28"/><path d="M470 124v-12M498 152h12M470 180v12M442 152h-12"/>${flow(a, "M186 252h286")}`,
  "5-4": (a) => `<path opacity=".22" d="M122 240V122M122 240h380"/><path d="M172 210v-38M242 190v-58M312 170v-78M382 150v-98"/>${flow(a, "M452 220V112")}`,
};

export function sketchFor(station: number, screenIdx: number, accent: string): string | null {
  const key = `${station}-${screenIdx}`;
  // explizit hinterlegte Skizzen haben Vorrang (z. B. „3-0" Geräte/Standby)
  if (sketchPaths[key]) return sketchPaths[key](accent);
  const type = screens[String(station)][screenIdx][0];
  const sketchKeys = ["RÄTSEL", "WISSEN", "FAKT", "MYTHOS", "MISSION 02", "MESSAUFTRAG", "ABSCHLUSSMISSION", "GESTALTEN"];
  if (!sketchKeys.includes(type)) return null;
  const generic = sketchPaths[`${station}-1`] ?? sketchPaths["1-1"];
  return generic(accent);
}
