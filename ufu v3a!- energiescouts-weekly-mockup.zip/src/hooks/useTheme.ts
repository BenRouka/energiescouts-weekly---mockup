import { useEffect, useState } from "react";

export type ThemeId = "tech" | "standard" | "playful";

export const THEMES: { id: ThemeId; label: string; hint: string; swatch: string[] }[] = [
  { id: "tech", label: "Tech", hint: "kühl, digital", swatch: ["#10171b", "#99cc00", "#235a5b"] },
  { id: "standard", label: "Standard", hint: "warm, petrol", swatch: ["#14282b", "#9fd14a", "#2c7071"] },
  { id: "playful", label: "Playful", hint: "verspielt, dezent", swatch: ["#182a30", "#aadd22", "#2f8a8c"] },
];

export function useTheme() {
  const [theme, setTheme] = useState<ThemeId>(() => {
    if (typeof localStorage !== "undefined") {
      const s = localStorage.getItem("ed-theme") as ThemeId | null;
      if (s === "tech" || s === "standard" || s === "playful") return s;
    }
    return "tech";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem("ed-theme", theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  return { theme, setTheme };
}
