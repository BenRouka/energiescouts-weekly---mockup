# Energiedetektive – HTML-Mockup

Öffne `index.html` lokal im Browser.

Enthalten:
- Intro / Willkommen
- Mini-Vorschau der 5 Stationen
- Dashboard mit 5 gleichmäßig breiten Hauptbuttons
- 2 Werkzeugleisten mit je 4 kleineren Buttons
- klickbarer Lernfluss für alle 5 Stationen
- Zurück / Weiter / Skip
- einfache animierte GIF-Skizzen als Referenz für spätere echte Animationen
- Platzhalter für echte Fotos, Schulpläne und Messdaten
- responsive für Beamer, iPad und Mobile

Die Skizzen orientieren sich ausschließlich an der gewünschten Linienlogik: reduzierte, cremefarbene Linien, gestrichelte Energie-/Bewegungsspuren und wenige Farbakzente.
