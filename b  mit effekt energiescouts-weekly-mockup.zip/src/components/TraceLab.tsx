import { useState } from "react";
import { traceGifs, tracePanels } from "../data/traceGifs";
import { originalGifs } from "../data/originalGifs";
import { cn } from "../utils/cn";

type Meta = {
  key: string;
  name: string;
  flow: string;
  used: string;
};

/* Überbegriff: Bewegungen ("MOVE IT") – Inhalt: die einzelnen Szenen */
const META: Meta[] = [
  { key: "mensch", name: "MENSCH", flow: "ENERGIE", used: "01/01" },
  { key: "fahrrad", name: "FAHRRAD", flow: "ANTRIEB · FLOW", used: "01/03" },
  { key: "schaukel", name: "SCHAUKEL", flow: "BEWEGUNG", used: "01/08" },
  { key: "tanzen", name: "TANZEN", flow: "RHYTHMUS", used: "INTRO" },
  { key: "gruppe", name: "FREIZEIT", flow: "GETEILTE ENERGIE", used: "03/05" },
];

/* wiederholtes Segment für das Laufband (2 × identischer Block = nahtloser Loop) */
const SEG = [0, 1, 2, 3, 4, 5];

function FlowTicker({ text }: { text: string }) {
  return (
    <div className="scene overflow-hidden border-t bd py-1.5 select-none" aria-hidden>
      <div className="marquee-slow marquee-track flex gap-6 w-max whitespace-nowrap">
        {[...SEG, ...SEG].map((i) => (
          <span key={i} className="font-tech text-[9px] tracking-[0.28em] t-accent inline-flex items-center gap-3">
            {text} <span className="dot-sep" aria-hidden />
          </span>
        ))}
      </div>
    </div>
  );
}

function SceneRow({ meta }: { meta: Meta }) {
  const [showAlt, setShowAlt] = useState(false);
  const panels = tracePanels[meta.key];
  const alt = originalGifs[meta.key];
  return (
    <article className="rise-in rounded-[var(--c-radius)] border bd surface-alt overflow-hidden flex flex-col">
      {/* HEADER: Szenenname */}
      <header className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-4 pt-3 pb-2.5 border-b bd">
        <h3 className="font-display font-semibold text-[15px] tracking-wide t-text">{meta.name}</h3>
        <span className="font-tech text-[10px] t-faint tracking-[0.12em]">{meta.used}</span>
        <div className="ml-auto flex rounded-lg border bd overflow-hidden text-[10px] font-semibold tracking-[0.1em]">
          <button
            onClick={() => setShowAlt(false)}
            className={cn("px-3 py-1.5 transition cursor-pointer", !showAlt ? "bg-accent" : "t-muted hover:t-text surface-2")}
          >
            NEU
          </button>
          <button
            onClick={() => setShowAlt(true)}
            disabled={!alt}
            className={cn(
              "px-3 py-1.5 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
              showAlt ? "bg-petrol t-text" : "t-muted hover:t-text surface-2"
            )}
          >
            ALT
          </button>
        </div>
      </header>

      {/* DETAIL: 3 Zuschnitte links · Gesamt-GIF rechts (goldener Schnitt ~1:1.6) */}
      <div className="grid grid-cols-[1fr_1.618fr] gap-px bd flex-1" style={{ background: "var(--c-line)" }}>
        <div className="scene p-2.5 flex flex-col gap-2 justify-center">
          {panels.map((p, i) => (
            <figure key={i} className="relative m-0 group">
              <img
                src={p}
                alt={`${meta.name} Stufe ${i + 1}`}
                className="w-full h-auto rounded-md border bd group-hover:bd-strong transition block"
              />
              <figcaption className="absolute left-1.5 top-1.5 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-[rgba(0,0,0,0.5)] t-accent tracking-wide">
                {i + 1}
              </figcaption>
            </figure>
          ))}
        </div>
        <figure className="scene m-0 grid place-items-center relative">
          <span className="absolute right-3 top-2.5 inline-flex items-center gap-1.5 text-[10px] t-muted tracking-[0.14em] font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-accent blink-dot" /> {showAlt ? "ALT" : "GIF"}
          </span>
          {showAlt && alt ? (
            <img src={alt} alt={`Alt ${meta.name}`} className="w-full h-auto block opacity-90" />
          ) : showAlt && !alt ? (
            <div className="text-center t-muted text-xs p-6 leading-relaxed">
              Kein altes GIF – die Gruppe ersetzt <span className="t-accent font-semibold">outdoor.gif</span>.
            </div>
          ) : (
            <img src={traceGifs[meta.key]} alt={`GIF ${meta.name}`} className="w-full h-auto block" />
          )}
        </figure>
      </div>

      {/* FOOTER: Flow als leicht animierte Laufschrift */}
      <FlowTicker text={meta.flow} />
    </article>
  );
}

export default function TraceLab({ onBack }: { onBack: () => void }) {
  return (
    <section className="view-in">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-4">
        <div>
          <div className="font-tech text-[12px] tracking-[0.2em] t-lime uppercase mb-1.5">Bewegungen</div>
          <h2 className="font-display font-semibold text-3xl md:text-[40px] tracking-tight t-lime leading-none">
            MOVE IT
          </h2>
          <div className="font-tech text-[11px] tracking-[0.14em] t-muted uppercase mt-2">
            {META.map((m) => m.name).join(" · ")}
          </div>
        </div>
        <button
          onClick={onBack}
          className="shrink-0 border bd-strong rounded-lg px-4 py-2.5 text-sm font-semibold tracking-wide surface hover:surface-2 hover:-translate-y-px transition cursor-pointer"
        >
          ← Übersicht
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {META.map((meta) => (
          <SceneRow key={meta.key} meta={meta} />
        ))}
      </div>
    </section>
  );
}
