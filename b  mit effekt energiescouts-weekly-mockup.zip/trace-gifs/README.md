# Trace-GIFs – aus `ref energytrace.png`

Quelle: [BenRouka/energiescouts-weekly---mockup](https://github.com/BenRouka/energiescouts-weekly---mockup) → `ref energytrace.png` (1536×1024)

## Aufbau der Referenz
- 5 Spalten (Szenen) × 3 Reihen (Bewegungsstufen) = **15 Panels**
- Header-Zeile mit Szenen-Titeln, Footer mit **LEGENDE** der Trace-Farben

## Farblogik (aus Referenz + Legende)
| Farbe | Hex | Bedeutung |
|---|---|---|
| Weiß | `#F7F7F7` | Linie / Skizze |
| Grün | `#A4D238` | Energie |
| Blau | `#4CA4C7` | Flow |
| Orange | `#F2911A` | Bewegung / Impuls |
| Violett | `#9E75C8` | Rhythmus |

## Szenen & Zuordnung in der App
| Szene | Datei | Einsatz |
|---|---|---|
| Mensch / Bewegung | `mensch.gif` | Station 01 · Screen 01 „Energie ist überall“ |
| Fahrrad / Energiekette | `fahrrad.gif` | Station 01 · Screen 03 „Energie hat verschiedene Formen“ |
| Schaukel / Umwandlung | `schaukel.gif` | Station 01 · Screen 08 „Energie-Detektiv“ |
| Tanzen / Rhythmus | `tanzen.gif` | Intro (Live-Bühne) |
| Gruppe / Energie-Aktion | `gruppe.gif` | Station 03 · Screen 06 „Energiefluss“ + Station 05 · Screen 06 „Unsere Energie-Aktion“ |

`outdoor.gif` (Sonne, altes Mockup) entfällt – in der neuen Referenz nicht enthalten.

## Pipeline (wenig Rendering)
1. **Crop**: 15 Panels aus dem PNG geschnitten (gleiche Spalten-Boxen über alle 3 Reihen → ruhende Bühne)
2. **Canvas**: zentriert auf 720×420, Hintergrund `#040709`
3. **Palette**: 12-Farb-Remap ohne Dithering (`palette.png`) → flache, GIF-freundliche Flächen
4. **GIF**: 3 Frames, Delay 500 ms, Endlos-Loop, `-layers Optimize`

Ergebnis: 19–39 KB pro animiertem GIF, 4–11 KB pro Panel.

```bash
# Nachvollziehen (ImageMagick):
convert ref-energytrace.png -crop 225x178+55+92 +repage -resize 680x380 \
  -background "#040709" -gravity center -extent 720x420 +dither -remap palette.png panel.png
convert f1.gif f2.gif f3.gif -loop 0 -delay 50 -dispose background -layers Optimize szene.gif
```
