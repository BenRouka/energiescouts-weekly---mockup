import { useState } from "react";
import { traceGifs, tracePanels } from "../data/traceGifs";
import { originalGifs } from "../data/originalGifs";
import { cn } from "../utils/cn";

type Meta = {
  key: string;
  name: string;
  flow: string;
  used: string;
};

const META: Meta[] = [
  { key: "mensch", name: "MENSCH", flow: "Energie", used: "Station 01 · Screen 01" },
  { key: "fahrrad", name: "FAHRRAD", flow: "Antrieb · Flow", used: "Station 01 · Screen 03" },
  { key: "schaukel", name: "SCHAUKEL", flow: "Bewegung", used: "Station 01 · Screen 08" },
  { key: "tanzen", name: "TANZEN", flow: "Rhythmus", used: "Intro" },
  { key: "gruppe", name: "GRUPPE", flow: "Geteilte Energie", used: "Station 03/05 · Aktion" },
];

const LEGENDE = [
  { c: "#eeffdd", label: "LINIE" },
  { c: "#99cc00", label: "ENERGIE" },
  { c: "#4CA4C7", label: "FLOW" },
  { c: "#F2911A", label: "BEWEGUNG" },
  { c: "#9E75C8", label: "RHYTHMUS" },
];

function SceneRow({ meta }: { meta: Meta }) {
  const [showAlt, setShowAlt] = useState(false);
  const panels = tracePanels[meta.key];
  const alt = originalGifs[meta.key];
  return (
    <article className="rise-in rounded-[var(--c-radius)] border bd surface-alt overflow-hidden">
      <header className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-4 pt-3 pb-2.5 border-b bd">
        <h3 className="font-display font-semibold text-[15px] tracking-wide t-text">{meta.name}</h3>
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full border bd t-accent tracking-wide">{meta.flow}</span>
        <span className="text-[11px] t-muted tracking-wide">{meta.used}</span>
        <div className="ml-auto flex rounded-lg border bd overflow-hidden text-[10px] font-semibold tracking-[0.1em]">
          <button
            onClick={() => setShowAlt(false)}
            className={cn("px-3 py-1.5 transition cursor-pointer", !showAlt ? "bg-accent" : "t-muted hover:t-text surface-2")}
          >
            NEU
          </button>
          <button
            onClick={() => setShowAlt(true)}
            disabled={!alt}
            className={cn(
              "px-3 py-1.5 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
              showAlt ? "bg-petrol t-text" : "t-muted hover:t-text surface-2"
            )}
          >
            ALT
          </button>
        </div>
      </header>

      {/* 3 Zuschnitte vertikal links · Gesamt-GIF rechts (goldener Schnitt ~1:1.6) */}
      <div className="grid grid-cols-[1fr_1.618fr] gap-px bd" style={{ background: "var(--c-line)" }}>
        <div className="scene p-2.5 flex flex-col gap-2 justify-center">
          {panels.map((p, i) => (
            <figure key={i} className="relative m-0 group">
              <img
                src={p}
                alt={`${meta.name} Stufe ${i + 1}`}
                className="w-full h-auto rounded-md border bd group-hover:bd-strong transition block"
              />
              <figcaption className="absolute left-1.5 top-1.5 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-[rgba(0,0,0,0.5)] t-accent tracking-wide">
                {i + 1}
              </figcaption>
            </figure>
          ))}
        </div>
        <figure className="scene m-0 grid place-items-center relative">
          <span className="absolute right-3 top-2.5 inline-flex items-center gap-1.5 text-[10px] t-muted tracking-[0.14em] font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-accent blink-dot" /> {showAlt ? "ALT" : "GIF"}
          </span>
          {showAlt && alt ? (
            <img src={alt} alt={`Alt ${meta.name}`} className="w-full h-auto block opacity-90" />
          ) : showAlt && !alt ? (
            <div className="text-center t-muted text-xs p-6 leading-relaxed">
              Kein altes GIF – die Gruppe ersetzt <span className="t-accent font-semibold">outdoor.gif</span>.
            </div>
          ) : (
            <img src={traceGifs[meta.key]} alt={`GIF ${meta.name}`} className="w-full h-auto block" />
          )}
        </figure>
      </div>
    </article>
  );
}

export default function TraceLab({ onBack }: { onBack: () => void }) {
  return (
    <section className="view-in">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-4">
        <div>
          <div className="text-[11px] tracking-[0.2em] font-semibold t-accent mb-1.5">TRACE-LAB</div>
          <h2 className="font-display font-semibold text-3xl md:text-[40px] tracking-tight t-text leading-none">
            15 Zuschnitte → 5 GIFs
          </h2>
        </div>
        <button
          onClick={onBack}
          className="shrink-0 border bd-strong rounded-lg px-4 py-2.5 text-sm font-semibold tracking-wide surface hover:surface-2 hover:-translate-y-px transition cursor-pointer"
        >
          ← Übersicht
        </button>
      </div>

      <div className="sticky top-[62px] z-10 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-[var(--c-radius)] border bd surface/95 px-4 py-2.5 mb-4 backdrop-blur">
        {LEGENDE.map((l) => (
          <span key={l.label} className="inline-flex items-center gap-1.5 text-[11px] font-semibold tracking-[0.08em] t-muted">
            <span className="w-3.5 h-1.5 rounded-full" style={{ background: l.c }} aria-hidden />
            {l.label}
          </span>
        ))}
        <span className="ml-auto hidden lg:block text-[10px] t-faint tracking-[0.08em]">
          CROP 720×420 · 12-FARB-REMAP · 3 FRAMES · LOOP
        </span>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {META.map((meta) => (
          <SceneRow key={meta.key} meta={meta} />
        ))}
      </div>
    </section>
  );
}
