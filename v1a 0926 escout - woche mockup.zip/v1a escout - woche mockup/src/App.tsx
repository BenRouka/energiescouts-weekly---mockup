import { useEffect, useState } from "react";
import { stations, tools, screens, sketchFor, type Screen } from "./data/content";
import { traceGifs } from "./data/traceGifs";
import { originalGifs } from "./data/originalGifs";
import TraceLab from "./components/TraceLab";
import { useTheme, THEMES } from "./hooks/useTheme";
import { cn } from "./utils/cn";

type View =
  | { name: "intro" }
  | { name: "dashboard" }
  | { name: "station"; station: number; screen: number }
  | { name: "tool"; tool: number }
  | { name: "tracelab" };

/* Ruhige SVG-Skizze mit sanftem Flow-Trace */
function Sketch({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 600 330" className="w-full h-auto block scene" role="img" aria-label="Skizze">
      <g
        fill="none"
        stroke="var(--c-text)"
        strokeWidth={7}
        strokeLinecap="round"
        strokeLinejoin="round"
        dangerouslySetInnerHTML={{ __html: d }}
      />
    </svg>
  );
}

function ThemePicker() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="flex items-center gap-1 rounded-lg border bd surface p-0.5" role="group" aria-label="Farbmodus">
      {THEMES.map((t) => (
        <button
          key={t.id}
          onClick={() => setTheme(t.id)}
          title={`${t.label} – ${t.hint}`}
          className={cn(
            "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] font-semibold tracking-wide transition cursor-pointer",
            theme === t.id ? "bg-accent" : "t-muted hover:t-text hover:surface-2"
          )}
        >
          <span className="flex gap-0.5" aria-hidden>
            {t.swatch.map((c, i) => (
              <span key={i} className="w-1.5 h-3 rounded-sm" style={{ background: c }} />
            ))}
          </span>
          <span className="hidden sm:inline">{t.label}</span>
        </button>
      ))}
    </div>
  );
}

const TICKER = ["ENERGIE IST ÜBERALL", "WÄRME", "STROM", "BEWEGUNG", "LAGE", "STRAHLUNG", "CHEMIE", "ENTDECKEN", "MESSEN", "VERSTEHEN", "HANDELN"];

export default function App() {
  const [view, setView] = useState<View>({ name: "intro" });
  useTheme();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [view]);

  const showDashboard = () => setView({ name: "dashboard" });

  return (
    <div className="min-h-screen flex flex-col dotgrid">
      {/* Topbar */}
      <header className="h-[62px] px-4 md:px-7 flex items-center justify-between gap-3 border-b bd sticky top-0 z-20 backdrop-blur-lg" style={{ background: "color-mix(in srgb, var(--c-bg) 88%, transparent)" }}>
        <button
          onClick={() => setView({ name: "intro" })}
          className="font-display font-semibold tracking-[0.1em] text-[13px] t-text hover:t-accent transition-colors cursor-pointer flex items-center gap-2.5"
        >
          <span className="inline-grid place-items-center w-7 h-7 rounded-lg bg-accent text-sm">⚡</span>
          ENERGIEDETEKTIVE
        </button>
        <nav className="flex items-center gap-1.5">
          <button
            onClick={showDashboard}
            className={cn("px-3 py-1.5 rounded-lg text-[12px] font-semibold tracking-[0.06em] transition cursor-pointer", view.name === "dashboard" ? "bg-accent" : "t-muted hover:t-text hover:surface-2")}
          >
            Übersicht
          </button>
          <button
            onClick={() => setView({ name: "tracelab" })}
            className={cn("px-3 py-1.5 rounded-lg text-[12px] font-semibold tracking-[0.06em] transition cursor-pointer border", view.name === "tracelab" ? "bg-accent border-transparent" : "bd t-accent hover:surface-2")}
          >
            Trace-Lab
          </button>
          <span className="mx-1 hidden md:block"><ThemePicker /></span>
        </nav>
      </header>

      <main className="w-full max-w-[1280px] mx-auto px-4 md:px-7 py-6 md:py-8 flex-1">
        {/* ---------------- INTRO ---------------- */}
        {view.name === "intro" && (
          <section className="view-in min-h-[calc(100vh-150px)] flex flex-col justify-center">
            {/* Hero über volle Breite */}
            <div>
              <div className="text-[11px] tracking-[0.22em] t-muted font-semibold uppercase mb-3">
                Projektwoche · Energie &amp; Klimaschutz
              </div>
              <h1 className="font-display font-semibold tracking-[-0.02em] leading-[0.98] text-[clamp(40px,5.6vw,68px)] t-text">
                Willkommen.
              </h1>
              <p className="text-[clamp(15px,1.5vw,19px)] leading-relaxed t-text max-w-[680px] mt-4" style={{ opacity: 0.88 }}>
                Energie ist überall. Diese Woche findest du heraus, wo sie herkommt, wie wir sie nutzen und wo wir sie verschwenden.
              </p>
              <div className="flex flex-wrap gap-2.5 mt-5">
                <button onClick={showDashboard} className="bg-accent font-display font-semibold tracking-[0.04em] rounded-xl px-5 py-3 hover:-translate-y-0.5 transition cursor-pointer">
                  Zur Übersicht →
                </button>
                <button onClick={() => setView({ name: "tracelab" })} className="border bd-strong t-accent surface font-display font-semibold tracking-[0.04em] rounded-xl px-5 py-3 hover:surface-2 hover:-translate-y-0.5 transition cursor-pointer">
                  Trace-GIFs ansehen
                </button>
              </div>
              <div className="md:hidden mt-5"><ThemePicker /></div>
            </div>

            {/* Struktur wie im Trace-Lab: links Einstiegsbuttons vertikal, rechts Bewegung · 50/50 */}
            <div className="grid md:grid-cols-2 gap-3 mt-8 items-stretch">
              {/* links: 5 Einstiegsbuttons vertikal, rechteckig */}
              <div className="flex flex-col gap-2">
                {stations.map((s, i) => (
                  <button
                    key={s.num}
                    onClick={() => setView({ name: "station", station: i + 1, screen: 0 })}
                    className="group flex-1 flex items-center gap-3 text-left border bd rounded-xl px-4 py-3 surface-alt hover:surface-2 hover:bd-strong hover:translate-x-0.5 transition cursor-pointer"
                  >
                    <span className="font-display font-semibold text-[20px] leading-none t-faint opacity-45 group-hover:opacity-75 transition w-8 shrink-0" aria-hidden>{s.num}</span>
                    <span className="inline-grid place-items-center w-8 h-8 shrink-0 rounded-lg surface-2 text-[15px]" style={{ color: s.accent }}>{s.icon}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[9px] t-faint tracking-[0.16em] font-semibold">STATION {s.num}</span>
                      <span className="block text-[14px] t-text leading-tight font-display font-medium truncate">{s.title}</span>
                    </span>
                    <span className="shrink-0 text-[13px] t-faint group-hover:t-accent transition" aria-hidden>→</span>
                  </button>
                ))}
              </div>

              {/* rechts: Loop-Panel, klein und bündig rechts */}
              <div className="rise-in flex" style={{ animationDelay: "100ms" }}>
                <div className="rounded-[var(--c-radius)] border bd overflow-hidden scene flex flex-col w-full">
                  <div className="flex items-center justify-between px-3.5 py-2 border-b bd text-[10px] tracking-[0.16em] font-semibold t-muted shrink-0">
                    <span>REF · MENSCH</span>
                    <span className="inline-flex items-center gap-1.5 t-accent"><span className="w-1.5 h-1.5 rounded-full bg-accent blink-dot" /> LOOP</span>
                  </div>
                  <div className="flex-1 grid place-items-center p-3">
                    <img
                      src={originalGifs.mensch}
                      alt="Referenz-GIF Mensch"
                      className="block w-full max-w-[300px] h-auto"
                      style={{ imageRendering: "auto" }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 border-y bd py-2.5 overflow-hidden select-none" aria-hidden>
              <div className="marquee-track flex gap-8 w-max whitespace-nowrap">
                {[...TICKER, ...TICKER].map((w, i) => (
                  <span key={i} className="text-[11px] tracking-[0.28em] font-semibold t-faint">{w} <span className="t-accent mx-3">·</span></span>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* ---------------- DASHBOARD ---------------- */}
        {view.name === "dashboard" && (
          <section className="view-in">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
              <div>
                <div className="text-[11px] tracking-[0.22em] t-muted font-semibold uppercase mb-1.5">Entdeckungsreise</div>
                <h2 className="font-display font-semibold tracking-tight text-[clamp(28px,3.6vw,48px)] t-text leading-none">5 Stationen</h2>
              </div>
              <button onClick={() => setView({ name: "intro" })} className="border bd-strong rounded-lg px-4 py-2.5 text-sm font-semibold surface hover:surface-2 transition cursor-pointer">← Willkommen</button>
            </div>

            {/* 5 Panels, ursprüngliche Form: gleichmäßig horizontal wie in der Intro-Vorschau */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
              {stations.map((s, i) => (
                <button
                  key={s.num}
                  onClick={() => setView({ name: "station", station: i + 1, screen: 0 })}
                  className="group relative text-left aspect-[7/8] p-4 border bd rounded-[var(--c-radius)] surface overflow-hidden hover:-translate-y-1 hover:bd-strong transition duration-200 cursor-pointer flex flex-col"
                >
                  <span className="absolute -right-2 -bottom-4 font-display font-semibold text-[80px] leading-none opacity-[0.07] group-hover:opacity-[0.13] transition" aria-hidden>{s.num}</span>
                  <span className="text-[28px] leading-none inline-block mb-auto" style={{ color: s.accent }}>{s.icon}</span>
                  <span className="block text-[10px] t-faint font-semibold tracking-[0.16em]">STATION {s.num}</span>
                  <span className="block font-display font-medium text-[17px] t-text mt-1.5 leading-tight">{s.title}</span>
                  <span className="block text-[12px] t-muted leading-snug mt-2 line-clamp-3">{s.teaser}</span>
                  <span className="mt-2 text-[12px] font-semibold opacity-0 group-hover:opacity-100 transition" style={{ color: s.accent }}>Öffnen →</span>
                </button>
              ))}
            </div>

            <div className="mt-7 pt-5 border-t bd">
              <div className="text-[11px] tracking-[0.22em] t-muted font-semibold uppercase mb-3">Werkzeuge &amp; Extras</div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {tools.map((tool, i) => (
                <button
                  key={tool.label}
                  onClick={() => setView({ name: "tool", tool: i })}
                  className="flex items-center gap-2.5 text-left border bd surface-alt rounded-xl px-3.5 py-3 hover:surface-2 hover:bd-strong hover:-translate-y-0.5 transition cursor-pointer"
                >
                  <span className="w-8 h-8 shrink-0 border bd rounded-lg grid place-items-center font-semibold t-accent text-[12px]">{tool.icon}</span>
                  <span className="min-w-0">
                    <strong className="block text-[12px] tracking-[0.04em] t-text font-display font-medium">{tool.label}</strong>
                    <span className="block text-[10px] t-muted mt-0.5 truncate">{tool.sub}</span>
                  </span>
                </button>
              ))}
            </div>
          </section>
        )}

        {view.name === "station" && (
          <StationView station={view.station} screen={view.screen} onScreen={(s) => setView({ name: "station", station: view.station, screen: s })} onDashboard={showDashboard} />
        )}
        {view.name === "tool" && <ToolView tool={view.tool} onBack={showDashboard} />}
        {view.name === "tracelab" && <TraceLab onBack={showDashboard} />}

        {view.name !== "station" && (
          <div className="text-center t-faint text-[10px] tracking-[0.12em] mt-8">BEAMER · IPAD · MOBILE · TRACE-GIFS AUS REF ENERGYTRACE.PNG</div>
        )}
      </main>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function StationView({
  station, screen, onScreen, onDashboard,
}: { station: number; screen: number; onScreen: (s: number) => void; onDashboard: () => void }) {
  const st = stations[station - 1];
  const data = screens[String(station)];
  const d: Screen = data[screen];
  const [type, title, text, gifKey, visualTitle, takeAway] = d;
  const isTask = text.includes("?");
  const last = data.length - 1;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && screen < last) onScreen(screen + 1);
      if (e.key === "ArrowLeft" && screen > 0) onScreen(screen - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen, last, onScreen]);

  const sketch = sketchFor(station, screen, st.accent);

  return (
    <section className="view-in" key={`${station}-${screen}`}>
      {/* Kopf */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-11 h-11 shrink-0 rounded-xl grid place-items-center border bd-strong text-[22px]" style={{ color: st.accent }}>{st.icon}</div>
        <div className="flex-1 min-w-0">
          <div className="text-[10px] tracking-[0.18em] t-faint font-semibold">STATION {st.num}</div>
          <h2 className="font-display font-semibold tracking-tight text-[clamp(20px,2.6vw,32px)] t-text leading-tight truncate">{st.title}</h2>
        </div>
        <button onClick={onDashboard} className="shrink-0 border bd-strong rounded-lg px-3.5 py-2 text-[13px] font-semibold surface hover:surface-2 transition cursor-pointer">Übersicht</button>
      </div>

      {/* Menüführung wie in A: Laufleiste mit Segmenten + Kapitel-Chips (aus Station-03-Screen) */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-[10px] t-faint font-semibold tracking-[0.14em] mb-1.5">
          <span>KAPITEL {String(screen + 1).padStart(2, "0")} / {String(data.length).padStart(2, "0")}</span>
          <span style={{ color: st.accent }}>{type}</span>
        </div>
        <div className="flex gap-1">
          {data.map((sc, i) => (
            <button
              key={i}
              onClick={() => onScreen(i)}
              title={sc[1]}
              className="group relative h-2 flex-1 rounded-full overflow-hidden cursor-pointer transition"
              style={{ background: "var(--c-line)" }}
              aria-label={`Kapitel ${i + 1}: ${sc[1]}`}
            >
              <span
                className="absolute inset-0 rounded-full transition-all duration-300"
                style={{ background: i <= screen ? st.accent : "transparent", opacity: i === screen ? 1 : i < screen ? 0.55 : 0 }}
              />
            </button>
          ))}
        </div>
      </div>

      {/* goldener Schnitt: Text 1.618 : Visual 1 */}
      <div className="grid lg:grid-cols-[1.618fr_1fr] gap-3.5 items-stretch">
        <article className="flex flex-col justify-between border bd rounded-[var(--c-radius)] surface-alt p-5 md:p-7">
          <div>
            <h1 className="font-display font-semibold tracking-[-0.02em] leading-[1.04] text-[clamp(26px,3.4vw,44px)] t-text mb-4">{title}</h1>
            <p className="text-[clamp(15px,1.5vw,18px)] leading-relaxed t-text max-w-[640px]" style={{ opacity: 0.9 }}>{text}</p>
            <div className="mt-5 px-4 py-3 border-l-[3px] surface rounded-r-lg text-[14px] leading-relaxed" style={{ borderColor: st.accent }}>
              {isTask ? (
                <><strong className="tracking-[0.08em] text-[11px]" style={{ color: st.accent }}>DEIN AUFTRAG: </strong>Erst vermuten. Dann begründen. Dann prüfen.</>
              ) : (
                <><strong className="tracking-[0.08em] text-[11px]" style={{ color: st.accent }}>MERKSATZ: </strong>{takeAway}</>
              )}
            </div>
          </div>
          {/* Navigation wie A: Zurück / Skip / Weiter */}
          <div className="flex flex-wrap justify-between gap-2 mt-6">
            <button onClick={() => screen > 0 && onScreen(screen - 1)} disabled={screen === 0} className="min-w-[112px] border bd-strong rounded-lg px-4 py-2.5 text-[13px] font-semibold surface hover:surface-2 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed">← Zurück</button>
            <button onClick={() => screen < last && onScreen(last)} className="min-w-[80px] border bd t-muted rounded-lg px-4 py-2.5 text-[13px] font-semibold hover:surface-2 hover:t-text transition cursor-pointer">Skip</button>
            <button onClick={() => (screen < last ? onScreen(screen + 1) : onDashboard())} className="min-w-[112px] bg-accent rounded-lg px-4 py-2.5 text-[13px] font-semibold hover:-translate-y-0.5 transition cursor-pointer">{screen < last ? "Weiter →" : "Fertig ✓"}</button>
          </div>
        </article>

        <aside className="flex flex-col justify-center border bd rounded-[var(--c-radius)] surface-alt p-4 md:p-5">
          <div className="text-[10px] tracking-[0.16em] t-faint font-semibold mb-3">{visualTitle}</div>
          {gifKey && traceGifs[gifKey] ? (
            <div className="rounded-lg overflow-hidden border bd">
              <img src={traceGifs[gifKey]} alt={`Trace-GIF: ${visualTitle}`} className="w-full h-auto block" />
              <div className="px-3 py-1.5 text-[9px] tracking-[0.16em] font-semibold t-accent scene border-t bd flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-accent blink-dot" /> {gifKey.toUpperCase()} · LOOP</div>
            </div>
          ) : sketch ? (
            <div className="rounded-lg overflow-hidden border bd"><Sketch d={sketch} /></div>
          ) : (
            <div className="aspect-[16/10] border border-dashed bd-strong rounded-lg grid place-items-center text-center px-6 t-muted text-[13px] leading-relaxed">
              ECHTES BILD / FOTO<br /><br />{visualTitle}
            </div>
          )}
        </aside>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */

function ToolView({ tool, onBack }: { tool: number; onBack: () => void }) {
  const t = tools[tool];
  const items: [string, string][] = [
    ["KURZ", "Einfacher Einstieg statt Informationswand."],
    ["MYTHOS", "Eine verbreitete Annahme kritisch prüfen."],
    ["MISSION", "Etwas selbst herausfinden oder entscheiden."],
    ["TRANSFER", "Das Wissen auf die eigene Schule anwenden."],
  ];
  return (
    <section className="view-in max-w-[880px] mx-auto pt-4 md:pt-10">
      <div className="text-[11px] tracking-[0.2em] t-muted font-semibold uppercase">{t.kicker}</div>
      <h1 className="font-display font-semibold tracking-[-0.02em] text-[clamp(32px,5vw,60px)] t-text leading-none mt-2 mb-4">{t.title}</h1>
      <p className="text-[clamp(15px,1.6vw,20px)] leading-relaxed t-text max-w-[680px]" style={{ opacity: 0.9 }}>{t.text}</p>
      <div className="grid sm:grid-cols-2 gap-2.5 mt-6">
        {items.map(([k, v]) => (
          <div key={k} className="border bd rounded-xl surface-alt p-4 hover:bd-strong transition">
            <strong className="font-display font-medium tracking-[0.08em] t-accent text-sm">{k}</strong>
            <div className="text-[13px] t-muted mt-1 leading-relaxed">{v}</div>
          </div>
        ))}
      </div>
      <button onClick={onBack} className="mt-6 bg-accent font-display font-semibold tracking-[0.04em] rounded-xl px-5 py-3 hover:-translate-y-0.5 transition cursor-pointer">← Zur Übersicht</button>
    </section>
  );
}
