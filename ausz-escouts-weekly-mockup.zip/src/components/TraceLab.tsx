import { useState } from "react";
import { traceGifs, tracePanels } from "../data/traceGifs";
import { originalGifs } from "../data/originalGifs";
import { cn } from "../utils/cn";

type Meta = {
  key: string;
  name: string;
  flow: string;
  color: string;
  used: string;
  caption: string;
};

// Trace-Farben aus der Legende in ref energytrace.png
// Reihenfolge chronologisch: TANZEN zuerst (Intro), MENSCH an Position 4 –
// die Einsatz-Nummern (01/01 …) laufen von oben nach unten aufsteigend.
// caption = Bildunterschrift aus Stufe 3 (im Panel-3-Bild abgeschnitten und
// hier statisch, bündig unter dem animierten GIF angeordnet).
const META: Meta[] = [
  { key: "tanzen", name: "TANZEN", flow: "RHYTHMUS", color: "#9E75C8", used: "INTRO", caption: "Tanzbewegungen drücken auf die Plattform. Die Mechanik treibt den Generator an und erzeugt Strom." },
  { key: "fahrrad", name: "FAHRRAD", flow: "FLOW", color: "#4CA4C7", used: "01/01", caption: "Die Beinbewegung treibt die Pedale. Der Generator wandelt die mechanische Energie in Strom um." },
  { key: "schaukel", name: "SCHAUKEL", flow: "BEWEGUNG", color: "#F2911A", used: "01/03", caption: "Vor- und Rückschwingen bewegt ein Seil/Mechanik, die den Generator antreibt und Strom erzeugt." },
  { key: "mensch", name: "MENSCH", flow: "ENERGIE", color: "#99cc00", used: "01/08", caption: "Chemische Energie aus Nahrung wird in Bewegung umgewandelt." },
  { key: "freizeit", name: "FREIZEIT", flow: "GETEILTE ENERGIE", color: "#99cc00", used: "03/06 · 05/06", caption: "Verschiedene Geräte werden bewegt und treiben Generatoren an. Die erzeugte Energie wird zusammengeführt." },
];

/* Footer: Flow als kleine, leicht animierte Laufschrift in der jeweiligen Trace-Farbe */
function FlowFooter({ meta }: { meta: Meta }) {
  const items = Array.from({ length: 12 });
  return (
    <footer className="border-t bd scene overflow-hidden select-none py-1.5" aria-label={`Flow: ${meta.flow}`}>
      <div className="marquee-track marquee-fast flex w-max whitespace-nowrap">
        {items.map((_, i) => (
          <span key={i} className="inline-flex items-center gap-1.5 pr-6 font-tech font-medium text-[10px] tracking-[0.16em]" style={{ color: meta.color }}>
            <span className="dot-fine" style={{ background: meta.color }} aria-hidden />
            {meta.flow}
          </span>
        ))}
      </div>
    </footer>
  );
}

function SceneRow({ meta }: { meta: Meta }) {
  const [showAlt, setShowAlt] = useState(false);
  const panels = tracePanels[meta.key];
  const alt = originalGifs[meta.key];
  return (
    <article className="rise-in rounded-[var(--c-radius)] border bd surface-alt overflow-hidden flex flex-col">
      {/* Header: Szene */}
      <header className="flex flex-wrap items-center gap-x-3 gap-y-1.5 px-4 pt-3 pb-2.5 border-b bd">
        <h3 className="font-display font-semibold text-[15px] tracking-wide t-text">{meta.name}</h3>
        <span className="font-tech font-medium text-[10px] t-muted tracking-[0.08em]">{meta.used}</span>
        <div className="ml-auto flex rounded-lg border bd overflow-hidden text-[10px] font-semibold tracking-[0.1em]">
          <button
            onClick={() => setShowAlt(false)}
            className={cn("px-3 py-1.5 transition cursor-pointer", !showAlt ? "bg-accent" : "t-muted hover:t-text surface-2")}
          >
            NEU
          </button>
          <button
            onClick={() => setShowAlt(true)}
            disabled={!alt}
            className={cn(
              "px-3 py-1.5 transition cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed",
              showAlt ? "bg-petrol t-text" : "t-muted hover:t-text surface-2"
            )}
          >
            ALT
          </button>
        </div>
      </header>

      {/* Detail: 3 Zuschnitte vertikal links · Gesamt-GIF rechts (goldener Schnitt ~1:1.6) */}
      <div className="grid grid-cols-[1fr_1.618fr] gap-px bd" style={{ background: "var(--c-line)" }}>
        <div className="scene p-2.5 flex flex-col gap-2 justify-center">
          {panels.map((p, i) => (
            <figure key={i} className="relative m-0 group">
              <img
                src={p}
                alt={`${meta.name} Stufe ${i + 1}`}
                className="w-full h-auto rounded-md border bd group-hover:bd-strong transition block"
              />
              <figcaption className="absolute left-1.5 top-1.5 text-[9px] font-semibold px-1.5 py-0.5 rounded bg-[rgba(0,0,0,0.5)] tracking-wide" style={{ color: meta.color }}>
                {i + 1}
              </figcaption>
            </figure>
          ))}
        </div>
        <figure className="scene m-0 relative flex flex-col">
          <span className="absolute right-3 top-2.5 inline-flex items-center gap-1.5 text-[10px] t-muted tracking-[0.14em] font-semibold z-10">
            <span className="w-1.5 h-1.5 rounded-full blink-dot" style={{ background: meta.color }} /> {showAlt ? "ALT" : "GIF"}
          </span>
          <div className="grid place-items-center flex-1">
            {showAlt && alt ? (
              <img src={alt} alt={`Alt ${meta.name}`} className="w-full h-auto block opacity-90" />
            ) : showAlt && !alt ? (
              <div className="text-center t-muted text-xs p-6 leading-relaxed">
                Kein altes GIF – Freizeit ersetzt <span className="t-accent font-semibold">outdoor.gif</span>.
              </div>
            ) : (
              <img src={traceGifs[meta.key]} alt={`GIF ${meta.name}`} className="w-full h-auto block" />
            )}
          </div>
          {/* Bildunterschrift aus Stufe 3: statisch, bündig links unter dem animierten GIF */}
          {!showAlt && (
            <figcaption className="border-t bd px-4 py-2.5 flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full shrink-0 mt-[5px]" style={{ background: meta.color }} aria-hidden />
              <span className="text-[12px] leading-[1.45] t-muted">{meta.caption}</span>
            </figcaption>
          )}
        </figure>
      </div>

      {/* Footer: Flow */}
      <FlowFooter meta={meta} />
    </article>
  );
}

export default function TraceLab({ onBack }: { onBack: () => void }) {
  return (
    <section className="view-in">
      <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
        <div>
          <div className="font-tech font-medium text-[11px] tracking-[0.14em] t-muted uppercase mb-1.5">Bewegungen</div>
          <h2 className="font-display font-semibold text-3xl md:text-[40px] tracking-tight t-lime leading-none">
            Move it
          </h2>
          <div className="font-tech font-medium text-[10px] tracking-[0.12em] t-faint uppercase mt-2">
            {META.map((m) => m.name).join(" · ")}
          </div>
        </div>
        <button
          onClick={onBack}
          className="shrink-0 border bd-strong rounded-lg px-4 py-2.5 text-sm font-semibold tracking-wide surface hover:surface-2 hover:-translate-y-px transition cursor-pointer"
        >
          ← Übersicht
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {META.map((meta) => (
          <SceneRow key={meta.key} meta={meta} />
        ))}
      </div>
    </section>
  );
}
